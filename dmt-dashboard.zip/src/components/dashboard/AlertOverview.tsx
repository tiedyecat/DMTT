'use client';

import { useQuery } from '@tanstack/react-query';
import { formatCurrency, formatDate } from '@/utils/formatters';

interface Alert {
  id: string;
  business_name: string;
  date: string;
  flagged_reason: string;
  spend: number;
  leads: number;
  purchases: number;
  cpa: number;
}

export default function AlertOverview() {
  const { data: highCpaAlerts, isLoading: isLoadingHighCpa } = useQuery<Alert[]>({
    queryKey: ['high-cpa-alerts'],
    queryFn: async () => {
      const response = await fetch('/api/alerts/high-cpa?limit=5');
      if (!response.ok) throw new Error('Failed to fetch high CPA alerts');
      const data = await response.json();
      return data.alerts;
    }
  });

  const { data: highSpendAlerts, isLoading: isLoadingHighSpend } = useQuery<Alert[]>({
    queryKey: ['high-spend-alerts'],
    queryFn: async () => {
      const response = await fetch('/api/alerts/high-spend?limit=5');
      if (!response.ok) throw new Error('Failed to fetch high spend alerts');
      const data = await response.json();
      return data.alerts;
    }
  });

  const { data: zeroConversionAlerts, isLoading: isLoadingZeroConversion } = useQuery<Alert[]>({
    queryKey: ['zero-conversion-alerts'],
    queryFn: async () => {
      const response = await fetch('/api/alerts/zero-conversion?limit=5');
      if (!response.ok) throw new Error('Failed to fetch zero conversion alerts');
      const data = await response.json();
      return data.alerts;
    }
  });

  if (isLoadingHighCpa || isLoadingHighSpend || isLoadingZeroConversion) {
    return <div>Loading alerts...</div>;
  }

  return (
    <div className="space-y-6">
      {/* High CPA Alerts */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">High CPA Alerts</h3>
        <div className="mt-2 space-y-2">
          {highCpaAlerts?.map((alert) => (
            <div key={alert.id} className="bg-red-50 p-3 rounded-md">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-900">{alert.business_name}</p>
                  <p className="text-xs text-gray-500">{formatDate(alert.date)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-red-600">CPA: {formatCurrency(alert.cpa)}</p>
                  <p className="text-xs text-gray-500">Spend: {formatCurrency(alert.spend)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* High Spend Alerts */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">High Spend Alerts</h3>
        <div className="mt-2 space-y-2">
          {highSpendAlerts?.map((alert) => (
            <div key={alert.id} className="bg-yellow-50 p-3 rounded-md">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-900">{alert.business_name}</p>
                  <p className="text-xs text-gray-500">{formatDate(alert.date)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-yellow-600">Spend: {formatCurrency(alert.spend)}</p>
                  <p className="text-xs text-gray-500">Leads: {alert.leads}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Zero Conversion Alerts */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">Zero Conversion Alerts</h3>
        <div className="mt-2 space-y-2">
          {zeroConversionAlerts?.map((alert) => (
            <div key={alert.id} className="bg-orange-50 p-3 rounded-md">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-900">{alert.business_name}</p>
                  <p className="text-xs text-gray-500">{formatDate(alert.date)}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-orange-600">No Conversions</p>
                  <p className="text-xs text-gray-500">Spend: {formatCurrency(alert.spend)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 