'use client';

import { useQuery } from '@tanstack/react-query';
import { formatCurrency } from '@/utils/formatters';

interface DailyChange {
  business_name: string;
  date: string;
  lead_change: number;
  purchase_change: number;
  spend_change: number;
}

interface ObjectiveSummary {
  campaign_name: string;
  business_name: string;
  date: string;
  campaign_objective: string;
  total_spend: number;
  total_clicks: number;
  total_leads: number;
  total_purchases: number;
  total_impressions: number;
  avg_cpa: number;
  avg_cpc: number;
  avg_ctr: number;
  avg_frequency: number;
}

export default function PerformanceTrends() {
  const { data: dailyChanges, isLoading: isLoadingDailyChanges } = useQuery<DailyChange[]>({
    queryKey: ['daily-performance-changes'],
    queryFn: async () => {
      const response = await fetch('/api/performance/daily-changes');
      if (!response.ok) throw new Error('Failed to fetch daily changes');
      return response.json();
    }
  });

  const { data: objectiveSummaries, isLoading: isLoadingObjectiveSummaries } = useQuery<ObjectiveSummary[]>({
    queryKey: ['objective-summaries'],
    queryFn: async () => {
      const response = await fetch('/api/performance/objective-summary');
      if (!response.ok) throw new Error('Failed to fetch objective summaries');
      return response.json();
    }
  });

  if (isLoadingDailyChanges || isLoadingObjectiveSummaries) {
    return <div>Loading performance trends...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Daily Performance Changes */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">Daily Performance Changes</h3>
        <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {dailyChanges?.map((change) => (
            <div key={`${change.business_name}-${change.date}`} className="bg-white p-4 rounded-lg border border-gray-200">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-900">{change.business_name}</p>
                  <p className="text-xs text-gray-500">{new Date(change.date).toLocaleDateString()}</p>
                </div>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-2">
                <div>
                  <p className="text-xs text-gray-500">Leads</p>
                  <p className={`text-sm font-medium ${change.lead_change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {change.lead_change >= 0 ? '+' : ''}{change.lead_change}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Purchases</p>
                  <p className={`text-sm font-medium ${change.purchase_change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {change.purchase_change >= 0 ? '+' : ''}{change.purchase_change}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Spend</p>
                  <p className={`text-sm font-medium ${change.spend_change >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {change.spend_change >= 0 ? '+' : ''}{formatCurrency(change.spend_change)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Objective Summary */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">Campaign Objective Performance</h3>
        <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {objectiveSummaries?.map((summary) => (
            <div key={`${summary.campaign_name}-${summary.date}`} className="bg-white p-4 rounded-lg border border-gray-200">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-medium text-gray-900">{summary.campaign_name}</p>
                  <p className="text-xs text-gray-500">{summary.campaign_objective}</p>
                </div>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <div>
                  <p className="text-xs text-gray-500">Spend</p>
                  <p className="text-sm font-medium">{formatCurrency(summary.total_spend)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">Leads</p>
                  <p className="text-sm font-medium">{summary.total_leads}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">CPA</p>
                  <p className="text-sm font-medium">{formatCurrency(summary.avg_cpa)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500">CTR</p>
                  <p className="text-sm font-medium">{(summary.avg_ctr * 100).toFixed(2)}%</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 