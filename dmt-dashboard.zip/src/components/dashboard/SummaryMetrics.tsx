'use client';

import { useQuery } from '@tanstack/react-query';
import { formatCurrency } from '@/utils/formatters';

interface SummaryData {
  business_name: string;
  date: string;
  total_leads: number;
  total_purchases: number;
  total_spend: number;
  total_clicks: number;
  total_impressions: number;
  avg_cpa: number;
  avg_cpc: number;
  avg_ctr: number;
}

interface Last7DaysData {
  business_name: string;
  leads: number;
  spend: number;
  purchases: number;
  avg_cpa: number;
}

export default function SummaryMetrics() {
  const { data: yesterdayData, isLoading: isLoadingYesterday } = useQuery<SummaryData[]>({
    queryKey: ['yesterday-summary'],
    queryFn: async () => {
      const response = await fetch('/api/summary/yesterday');
      if (!response.ok) throw new Error('Failed to fetch yesterday summary');
      return response.json();
    }
  });

  const { data: last7DaysData, isLoading: isLoadingLast7Days } = useQuery<Last7DaysData[]>({
    queryKey: ['last-7-days-summary'],
    queryFn: async () => {
      const response = await fetch('/api/summary/last-7-days');
      if (!response.ok) throw new Error('Failed to fetch last 7 days summary');
      return response.json();
    }
  });

  if (isLoadingYesterday || isLoadingLast7Days) {
    return <div>Loading summary metrics...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Yesterday's Summary */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">Yesterday's Performance</h3>
        <div className="mt-2 grid grid-cols-2 gap-4">
          {yesterdayData?.map((summary) => (
            <div key={summary.business_name} className="space-y-2">
              <p className="text-sm font-medium text-gray-900">{summary.business_name}</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500">Leads</p>
                  <p className="font-medium">{summary.total_leads}</p>
                </div>
                <div>
                  <p className="text-gray-500">Purchases</p>
                  <p className="font-medium">{summary.total_purchases}</p>
                </div>
                <div>
                  <p className="text-gray-500">Spend</p>
                  <p className="font-medium">{formatCurrency(summary.total_spend)}</p>
                </div>
                <div>
                  <p className="text-gray-500">CPA</p>
                  <p className="font-medium">{formatCurrency(summary.avg_cpa)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Last 7 Days Summary */}
      <div>
        <h3 className="text-sm font-medium text-gray-500">Last 7 Days</h3>
        <div className="mt-2 grid grid-cols-2 gap-4">
          {last7DaysData?.map((summary) => (
            <div key={summary.business_name} className="space-y-2">
              <p className="text-sm font-medium text-gray-900">{summary.business_name}</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500">Leads</p>
                  <p className="font-medium">{summary.leads}</p>
                </div>
                <div>
                  <p className="text-gray-500">Purchases</p>
                  <p className="font-medium">{summary.purchases}</p>
                </div>
                <div>
                  <p className="text-gray-500">Spend</p>
                  <p className="font-medium">{formatCurrency(summary.spend)}</p>
                </div>
                <div>
                  <p className="text-gray-500">CPA</p>
                  <p className="font-medium">{formatCurrency(summary.avg_cpa)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
} 