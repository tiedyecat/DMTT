'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2, AlertCircle, CheckCircle2, Database, Table, EyeIcon } from 'lucide-react'

interface QueryResponse {
  type: 'summary' | 'alert' | 'performance' | 'help' | 'ai_only' | 'ai_report' | 'empty' | 'error' | 'openai_test' | 'schema' | 'views' | 'database_test'
  data: any
  message: string
  aiResponse?: string
  ai_content?: string
  error?: string
  openai_status?: string
  success?: boolean
}

export default function QueryBox() {
  const [query, setQuery] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [response, setResponse] = useState<QueryResponse | null>(null)
  const [teamMember, setTeamMember] = useState('')
  const [apiError, setApiError] = useState<string | null>(null)
  const [openaiStatus, setOpenaiStatus] = useState<'unknown' | 'connected' | 'error'>('unknown')

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!query.trim() || !teamMember.trim()) return
    setIsLoading(true)
    setResponse(null) // Clear previous response
    setApiError(null) // Clear previous errors

    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query, teamMember }),
      })

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `API Error: ${res.statusText}`);
      }

      const data = await res.json();
      setResponse(data);
      
      // Update OpenAI status if available
      if (data.openai_status) {
        setOpenaiStatus(data.openai_status === 'connected' || data.openai_status === 'available' ? 'connected' : 'error');
      }
      
      // Log response for debugging
      console.log('API Response:', data);
    } catch (error) {
      console.error('Error processing query:', error);
      setApiError(error instanceof Error ? error.message : 'Unknown error');
      setResponse({
        type: 'error',
        data: null,
        message: `Error processing query: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setIsLoading(false);
    }
  }

  const generateDailyReport = async () => {
    if (!teamMember.trim()) return
    setIsLoading(true)
    setResponse(null) // Clear previous response
    setApiError(null) // Clear previous errors
    
    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: 'generate daily report',
          teamMember
        }),
      })

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `API Error: ${res.statusText}`);
      }

      const data = await res.json();
      setResponse(data);
      
      // Update OpenAI status if available
      if (data.openai_status) {
        setOpenaiStatus(data.openai_status === 'connected' || data.openai_status === 'available' ? 'connected' : 'error');
      }
      
      // Log response for debugging
      console.log('Daily Report Response:', data);
    } catch (error) {
      console.error('Error generating daily report:', error);
      setApiError(error instanceof Error ? error.message : 'Unknown error');
      setResponse({
        type: 'error',
        data: null,
        message: `Error generating report: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setIsLoading(false);
    }
  }

  const testOpenAI = async () => {
    setIsLoading(true)
    setResponse(null) // Clear previous response
    setApiError(null) // Clear previous errors
    
    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: 'test openai',
          teamMember: teamMember || 'Tester'
        }),
      })

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `API Error: ${res.statusText}`);
      }

      const data = await res.json();
      setResponse(data);
      
      // Update OpenAI status based on the test result
      setOpenaiStatus(data.success ? 'connected' : 'error');
      
      // Log response for debugging
      console.log('OpenAI Test Response:', data);
    } catch (error) {
      console.error('Error testing OpenAI:', error);
      setApiError(error instanceof Error ? error.message : 'Unknown error');
      setOpenaiStatus('error');
      setResponse({
        type: 'error',
        data: null,
        message: `Error testing OpenAI: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setIsLoading(false);
    }
  }

  // Add a button to test database connectivity
  const testDatabase = async () => {
    setIsLoading(true)
    setResponse(null) // Clear previous response
    setApiError(null) // Clear previous errors
    
    try {
      const res = await fetch('/api/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: 'test database',
          teamMember: teamMember || 'Tester'
        }),
      })

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || `API Error: ${res.statusText}`);
      }

      const data = await res.json();
      setResponse(data);
      
      // Log response for debugging
      console.log('Database Test Response:', data);
    } catch (error) {
      console.error('Error testing database:', error);
      setApiError(error instanceof Error ? error.message : 'Unknown error');
      setResponse({
        type: 'error',
        data: null,
        message: `Error testing database: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setIsLoading(false);
    }
  }

  // Basic response renderer - adjust as needed for better data display
  const renderResponseData = (data: any) => {
    if (!data) return null
    
    // For database test results
    if (response?.type === 'database_test') {
      return (
        <div>
          <div className="flex items-center mt-2">
            <span className={data.hasExecSql ? "text-green-600" : "text-yellow-600"}>
              {data.hasExecSql ? (
                <CheckCircle2 className="inline-block w-5 h-5 mr-1" />
              ) : (
                <AlertCircle className="inline-block w-5 h-5 mr-1" />
              )}
              SQL Function: {data.hasExecSql ? 'Available' : 'Not Available'}
            </span>
          </div>
          
          {data.tables && data.tables.length > 0 && (
            <div className="mt-3">
              <h5 className="text-sm font-semibold mb-2">Tables in Database:</h5>
              <div className="bg-gray-50 p-2 rounded-md text-xs">
                <ul className="list-disc pl-5">
                  {data.tables.map((table: any, i: number) => (
                    <li key={i}>{table.tablename}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      );
    }
    
    // If data is an object with metrics and alerts (from daily report)
    if (data.metrics && data.alerts) {
      return (
        <div>
          <h4 className="text-md font-semibold mt-3 mb-2">Metrics (Last 7 Days)</h4>
          <pre className="bg-gray-100 p-2 rounded-md text-xs overflow-auto">
            {JSON.stringify(data.metrics, null, 2)}
          </pre>
          <h4 className="text-md font-semibold mt-3 mb-2">Alerts</h4>
          <pre className="bg-gray-100 p-2 rounded-md text-xs overflow-auto">
            {JSON.stringify(data.alerts, null, 2)}
          </pre>
        </div>
      )
    }
    
    // For schema response (tables)
    if (response?.type === 'schema' && Array.isArray(data)) {
      return (
        <div>
          <h4 className="text-md font-semibold mt-3 mb-2 flex items-center">
            <Database className="w-4 h-4 mr-2" />
            Database Schema ({data.length} tables)
          </h4>
          <div className="space-y-4">
            {data.map((table: any, i: number) => (
              <div key={i} className="border rounded-md p-3 bg-white">
                <h5 className="font-semibold flex items-center">
                  <Table className="w-4 h-4 mr-2" />
                  {table.table_name} 
                  <span className="ml-2 text-xs text-gray-500">({table.table_type})</span>
                </h5>
                {table.columns && table.columns.length > 0 ? (
                  <div className="mt-2 overflow-x-auto">
                    <table className="min-w-full text-xs">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="px-2 py-1 text-left">Column</th>
                          <th className="px-2 py-1 text-left">Type</th>
                          <th className="px-2 py-1 text-left">Nullable</th>
                          <th className="px-2 py-1 text-left">Default</th>
                        </tr>
                      </thead>
                      <tbody>
                        {table.columns.map((col: any, j: number) => (
                          <tr key={j} className={j % 2 === 0 ? 'bg-gray-50' : ''}>
                            <td className="px-2 py-1">{col.column_name}</td>
                            <td className="px-2 py-1">{col.data_type}</td>
                            <td className="px-2 py-1">{col.is_nullable}</td>
                            <td className="px-2 py-1">{col.column_default || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">No column information available</p>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }
    
    // For views response
    if (response?.type === 'views' && Array.isArray(data)) {
      return (
        <div>
          <h4 className="text-md font-semibold mt-3 mb-2 flex items-center">
            <EyeIcon className="w-4 h-4 mr-2" />
            Database Views ({data.length} views)
          </h4>
          <div className="space-y-4">
            {data.map((view: any, i: number) => (
              <div key={i} className="border rounded-md p-3 bg-white">
                <h5 className="font-semibold flex items-center">
                  <EyeIcon className="w-4 h-4 mr-2" />
                  {view.table_name}
                </h5>
                
                {view.columns && view.columns.length > 0 ? (
                  <div className="mt-2 overflow-x-auto">
                    <h6 className="text-xs font-medium mb-1">Columns:</h6>
                    <table className="min-w-full text-xs">
                      <thead>
                        <tr className="bg-gray-100">
                          <th className="px-2 py-1 text-left">Column</th>
                          <th className="px-2 py-1 text-left">Type</th>
                          <th className="px-2 py-1 text-left">Nullable</th>
                        </tr>
                      </thead>
                      <tbody>
                        {view.columns.map((col: any, j: number) => (
                          <tr key={j} className={j % 2 === 0 ? 'bg-gray-50' : ''}>
                            <td className="px-2 py-1">{col.column_name}</td>
                            <td className="px-2 py-1">{col.data_type}</td>
                            <td className="px-2 py-1">{col.is_nullable}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 mt-1">No column information available</p>
                )}
                
                {view.view_definition && (
                  <div className="mt-2">
                    <h6 className="text-xs font-medium mb-1">Definition:</h6>
                    <pre className="bg-gray-50 p-2 rounded-md text-xs overflow-auto max-h-32">
                      {view.view_definition}
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      );
    }
    
    // Otherwise, display raw JSON
    return (
      <pre className="bg-gray-100 p-2 rounded-md text-xs overflow-auto">
        {JSON.stringify(data, null, 2)}
      </pre>
    )
  }

  // Render AI response if available
  const renderAIResponse = () => {
    if (!response) return null;
    
    // Check for specific AI content from a report
    if (response.ai_content) {
      return (
        <div className="mt-4 p-3 bg-blue-50 rounded-md border border-blue-200">
          <h4 className="text-md font-semibold mb-2">AI Report</h4>
          <div className="text-sm whitespace-pre-wrap">
            {response.ai_content}
          </div>
        </div>
      );
    }
    
    // Check for AI response from a general query
    if (response.aiResponse) {
      return (
        <div className="mt-4 p-3 bg-blue-50 rounded-md border border-blue-200">
          <h4 className="text-md font-semibold mb-2">AI Response</h4>
          <div className="text-sm whitespace-pre-wrap">
            {response.aiResponse}
          </div>
        </div>
      );
    }
    
    return null;
  }

  // Display OpenAI status indicator
  const renderOpenAIStatus = () => {
    if (openaiStatus === 'unknown') {
      return null;
    }
    
    return (
      <div className={`mt-2 text-sm flex items-center ${openaiStatus === 'connected' ? 'text-green-600' : 'text-red-600'}`}>
        {openaiStatus === 'connected' ? (
          <>
            <CheckCircle2 className="w-4 h-4 mr-1" />
            OpenAI connected
          </>
        ) : (
          <>
            <AlertCircle className="w-4 h-4 mr-1" />
            OpenAI not connected
          </>
        )}
      </div>
    );
  }

  return (
    <Card className="w-full shadow-sm mb-6">
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Query Dashboard</span>
          {renderOpenAIStatus()}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <label htmlFor="teamMember" className="block text-sm font-medium text-gray-700 mb-1">
            Your Name
          </label>
          <Input
            id="teamMember"
            value={teamMember}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTeamMember(e.target.value)}
            placeholder="Enter your name (e.g., Morgan)"
            disabled={isLoading}
          />
        </div>

        <div className="flex gap-2 mb-4">
          <Button
            onClick={generateDailyReport}
            disabled={!teamMember || isLoading}
            className="flex-1"
          >
            {isLoading && query === 'generate daily report' ? (
               <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating Report...</>
            ) : (
              'Generate Daily Report'
            )}
          </Button>
          
          <Button
            onClick={testOpenAI}
            disabled={isLoading}
            variant="outline"
            className="whitespace-nowrap"
          >
            {isLoading && query === 'test openai' ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Testing...</>
            ) : (
              'Test AI Connection'
            )}
          </Button>
          
          <Button
            onClick={testDatabase}
            disabled={isLoading}
            variant="outline"
            className="whitespace-nowrap"
          >
            {isLoading && query === 'test database' ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Testing...</>
            ) : (
              'Test Database'
            )}
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-2">
          <div>
            <label htmlFor="queryInput" className="sr-only">
              Ask a question
            </label>
            <div className="flex gap-2">
              <Input
                id="queryInput"
                name="query"
                placeholder="Or ask a question (e.g., 'show high CPA alerts')"
                value={query}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setQuery(e.target.value)}
                disabled={isLoading || !teamMember}
              />
              <Button
                type="submit"
                disabled={isLoading || !teamMember || !query}
              >
                {isLoading && query !== 'generate daily report' && query !== 'test openai' && query !== 'test database' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  'Ask'
                )}
              </Button>
            </div>
          </div>
        </form>
        
        {apiError && (
          <div className="mt-4 p-3 bg-red-50 rounded-md border border-red-200 text-red-800 text-sm">
            <strong>Error:</strong> {apiError}
          </div>
        )}

        {response && (
          <Card className="mt-4 bg-gray-50">
            <CardHeader className="pb-2 pt-4">
              <CardTitle className="text-sm font-medium">Response</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-800 mb-2">{response.message}</p>
              {renderAIResponse()}
              {renderResponseData(response.data)}
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
} 