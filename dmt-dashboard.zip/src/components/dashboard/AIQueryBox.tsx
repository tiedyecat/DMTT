import { useState } from 'react'
import { Button } from '@/components/ui/button'

interface Metrics {
  totalSpend: number
  totalImpressions: number
  totalClicks: number
  totalConversions: number
  avgCPA: number
  avgCTR: number
  avgCPC: number
}

interface DateRange {
  from: string
  to: string
}

interface AIResponse {
  success: boolean
  query: string
  context?: {
    businessId?: string
    dateRange?: string
    dataType?: string
    businessName?: string
  }
  metrics?: Metrics
  dateRange?: DateRange
  schema?: {
    tables: any[]
    views: any[]
    triggers: any[]
  }
  analysis: string
  error?: string
  errorType?: 'database' | 'no_data' | 'ai' | 'schema' | 'unknown'
}

const ERROR_MESSAGES = {
  database: 'There was an error connecting to the database. Please try again later.',
  no_data: 'No data was found for your query. Try adjusting your filters.',
  ai: 'The AI service encountered an error. Please try again.',
  schema: 'There was an error fetching the database schema. Please try again.',
  unknown: 'An unexpected error occurred. Please try again.'
}

export default function AIQueryBox() {
  const [query, setQuery] = useState('')
  const [businessId, setBusinessId] = useState('')
  const [dateRange, setDateRange] = useState('last_7_days')
  const [loading, setLoading] = useState(false)
  const [response, setResponse] = useState<AIResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setResponse(null)

    try {
      const res = await fetch('/api/ai-edge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, businessId, dateRange }),
      })

      if (!res.ok) {
        const errorData = await res.json()
        throw new Error(errorData.error || 'Failed to get AI response')
      }

      const data = await res.json()
      setResponse(data)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-4 bg-white rounded-lg shadow">
      <h2 className="text-xl font-semibold mb-4">AI Query Assistant</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="query" className="block text-sm font-medium text-gray-700">
            Ask a question about your data
          </label>
          <textarea
            id="query"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            rows={3}
            placeholder="E.g., How is our CPA trending?"
            required
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label htmlFor="businessId" className="block text-sm font-medium text-gray-700">
              Business ID (optional)
            </label>
            <input
              type="text"
              id="businessId"
              value={businessId}
              onChange={(e) => setBusinessId(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
              placeholder="Enter business ID"
            />
          </div>
          
          <div>
            <label htmlFor="dateRange" className="block text-sm font-medium text-gray-700">
              Date Range
            </label>
            <select
              id="dateRange"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            >
              <option value="last_7_days">Last 7 Days</option>
              <option value="last_30_days">Last 30 Days</option>
              <option value="last_90_days">Last 90 Days</option>
            </select>
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
            loading ? 'bg-indigo-400' : 'bg-indigo-600 hover:bg-indigo-700'
          } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500`}
        >
          {loading ? 'Analyzing...' : 'Get Insights'}
        </button>
      </form>

      {error && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-md">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {response && (
        <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-md">
          <pre className="whitespace-pre-wrap text-sm">{response.analysis}</pre>
        </div>
      )}
    </div>
  )
} 