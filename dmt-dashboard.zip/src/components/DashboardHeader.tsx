'use client';

import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import { useState } from 'react';

// Define interfaces for the API response
interface Column {
  column_name: string;
  data_type: string;
  is_nullable: string;
  column_default: string | null;
}

interface PrimaryKey {
  column_name: string;
}

interface Index {
  index_name: string;
  column_name: string;
  is_unique: boolean;
}

interface Table {
  name: string;
  type: string;
  columns?: Column[];
  primaryKeys?: PrimaryKey[];
  indexes?: Index[];
}

interface View {
  table_name: string;
  view_definition?: string;
}

interface TableResponse {
  tables: Table[];
  views?: View[];
  timestamp?: string;
  source?: string;
  message?: string;
  error?: string;
}

interface IndexGroup {
  name: string;
  columns: string[];
  isUnique: boolean;
}

export default function DashboardHeader() {
  const [isLoading, setIsLoading] = useState(false);

  const testApi = async () => {
    try {
      const response = await fetch('/api/hello');
      const data = await response.json();
      alert(data.message);
    } catch (error) {
      alert('Error testing API');
    }
  };

  const testSupabase = async () => {
    try {
      const response = await fetch('/api/test-supabase');
      const data = await response.json();
      alert(JSON.stringify(data, null, 2));
    } catch (error) {
      alert('Error testing Supabase connection');
    }
  };

  const listTables = async () => {
    try {
      setIsLoading(true);
      const response = await fetch('/api/list-tables');
      const data = await response.json() as TableResponse;
      
      if (data.error) {
        alert(`Error: ${data.error}\n${data.message || ''}`);
        return;
      }

      // Format the schema information for display
      let formattedOutput = '';
      
      // Tables
      if (data.tables && data.tables.length > 0) {
        formattedOutput += `Found ${data.tables.length} tables:\n\n`;
        
        data.tables.forEach((table: Table, i: number) => {
          formattedOutput += `${i+1}. ${table.name} (${table.type})\n`;
          
          if (table.columns && table.columns.length > 0) {
            formattedOutput += `   Columns:\n`;
            table.columns.forEach((col: Column) => {
              const nullable = col.is_nullable === 'YES' ? 'NULL' : 'NOT NULL';
              const defaultVal = col.column_default ? ` DEFAULT ${col.column_default}` : '';
              formattedOutput += `   - ${col.column_name}: ${col.data_type} ${nullable}${defaultVal}\n`;
            });
          }
          
          if (table.primaryKeys && table.primaryKeys.length > 0) {
            formattedOutput += `   Primary Keys: ${table.primaryKeys.map((pk: PrimaryKey) => pk.column_name).join(', ')}\n`;
          }
          
          if (table.indexes && table.indexes.length > 0) {
            formattedOutput += `   Indexes:\n`;
            const indexesByName: Record<string, IndexGroup> = {};
            
            // Group indexes by name
            table.indexes.forEach((idx: Index) => {
              if (!indexesByName[idx.index_name]) {
                indexesByName[idx.index_name] = {
                  name: idx.index_name,
                  columns: [],
                  isUnique: idx.is_unique
                };
              }
              indexesByName[idx.index_name].columns.push(idx.column_name);
            });
            
            // Display each index
            Object.values(indexesByName).forEach((idx: IndexGroup) => {
              const uniqueStr = idx.isUnique ? 'UNIQUE ' : '';
              formattedOutput += `   - ${uniqueStr}INDEX ${idx.name} (${idx.columns.join(', ')})\n`;
            });
          }
          
          formattedOutput += '\n';
        });
      } else {
        formattedOutput += 'No tables found.\n\n';
      }
      
      // Views
      if (data.views && data.views.length > 0) {
        formattedOutput += `\nFound ${data.views.length} views:\n\n`;
        data.views.forEach((view: View, i: number) => {
          formattedOutput += `${i+1}. ${view.table_name}\n`;
          if (view.view_definition) {
            const truncatedDef = view.view_definition.length > 100 
              ? view.view_definition.substring(0, 100) + '...' 
              : view.view_definition;
            formattedOutput += `   Definition: ${truncatedDef}\n`;
          }
          formattedOutput += '\n';
        });
      }
      
      // Timestamp
      if (data.timestamp) {
        formattedOutput += `\nData retrieved at: ${new Date(data.timestamp).toLocaleString()}`;
      }
      
      // Source if applicable
      if (data.source) {
        formattedOutput += `\nData source: ${data.source}`;
      }
      
      // Message if applicable
      if (data.message) {
        formattedOutput += `\nNote: ${data.message}`;
      }
      
      // Show the formatted output
      alert(formattedOutput);
    } catch (error) {
      alert(`Error listing tables: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <header className="bg-white shadow">
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900">Dashboard</h1>
        <div className="flex items-center gap-4">
          <div className="flex items-center">
            <input
              type="text"
              placeholder="Search..."
              className="rounded-md border-0 py-1.5 pl-3 pr-10 text-gray-900 ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600"
            />
            <MagnifyingGlassIcon className="h-5 w-5 text-gray-400 -ml-8" />
          </div>
          <button
            onClick={testApi}
            className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
          >
            Test API
          </button>
          <button
            onClick={testSupabase}
            className="rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-green-500"
          >
            Test DB
          </button>
          <button
            onClick={listTables}
            disabled={isLoading}
            className={`rounded-md ${isLoading ? 'bg-blue-400' : 'bg-blue-600 hover:bg-blue-500'} px-3 py-2 text-sm font-semibold text-white shadow-sm flex items-center`}
          >
            {isLoading ? 'Loading...' : 'List Tables'}
          </button>
        </div>
      </div>
    </header>
  );
} 