'use client'

import { useState } from 'react'
import { Input } from './ui/input'
import { Button } from './ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Loader2, Search, AlertCircle, BarChart, Brain } from 'lucide-react'

interface QueryResponse {
  type: 'summary' | 'alert' | 'help' | 'ai_analysis'
  data: any
  message: string
  analysis?: string
}

export function QueryBox() {
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)
  const [aiLoading, setAiLoading] = useState(false)
  const [response, setResponse] = useState<QueryResponse | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim()) return

    setLoading(true)
    try {
      console.log('Submitting query:', query)
      // Use the mock endpoint which returns synthetic data for testing
      const res = await fetch('/api/mock-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query })
      })

      if (!res.ok) throw new Error(`Error ${res.status}: ${res.statusText}`)
      
      const data = await res.json()
      console.log('API response:', data)
      setResponse(data)
    } catch (error) {
      console.error('Error fetching response:', error)
      setResponse({
        type: 'help',
        data: null,
        message: `Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`
      })
    } finally {
      setLoading(false)
    }
  }

  const analyzeWithAI = async () => {
    if (!response?.data) return
    
    setAiLoading(true)
    try {
      const res = await fetch('/api/ai-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          query: `Analyze this ${response.type === 'alert' ? 'alert' : ''} data and provide insights: ${query}`,
          data: response.data 
        })
      })

      if (!res.ok) throw new Error(`Error ${res.status}: ${res.statusText}`)
      
      const analysisResponse = await res.json()
      
      // Update the current response with AI analysis
      setResponse({
        ...response,
        type: 'ai_analysis',
        analysis: analysisResponse.analysis,
        message: 'AI Analysis Complete'
      })
    } catch (error) {
      console.error('Error getting AI analysis:', error)
      // Don't change the response, just show an alert
      alert(`AI Analysis Error: ${error instanceof Error ? error.message : 'Unknown error occurred'}`)
    } finally {
      setAiLoading(false)
    }
  }

  // Suggested queries you can click on directly
  const suggestedQueries = [
    'Show Facebook ads performance',
    'Show audience demographics',
    'Any alerts or flags?',
    'Show AI summaries'
  ]

  const handleSuggestedQuery = (suggested: string) => {
    setQuery(suggested)
    handleSubmit(new Event('submit') as any)
  }

  // Format a basic table from the data
  const renderDataTable = (data: any[]) => {
    if (!data || !data.length) return <p>No data available</p>
    
    // Get keys from first item
    const keys = Object.keys(data[0])
    // Exclude certain columns for cleaner display
    const displayColumns = keys.filter(k => 
      !['id', 'created_at', 'updated_at'].includes(k)
    ).slice(0, 5) // Limit to first 5 columns for readability
    
    return (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 text-sm">
          <thead className="bg-gray-50">
            <tr>
              {displayColumns.map(key => (
                <th key={key} className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  {key.replace(/_/g, ' ')}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {data.slice(0, 5).map((row, i) => (
              <tr key={i}>
                {displayColumns.map(key => (
                  <td key={key} className="px-4 py-2 whitespace-nowrap">
                    {typeof row[key] === 'object' ? JSON.stringify(row[key]) : row[key]?.toString() || '-'}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {data.length > 5 && (
          <div className="text-sm text-gray-500 mt-2 px-4">
            Showing 5 of {data.length} results
          </div>
        )}
      </div>
    )
  }

  const renderResponse = () => {
    if (!response) return null

    return (
      <Card className="mt-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-medium flex items-center">
            {response.type === 'alert' && <AlertCircle className="mr-2 h-5 w-5 text-amber-500" />}
            {response.type === 'summary' && <BarChart className="mr-2 h-5 w-5 text-blue-500" />}
            {response.type === 'ai_analysis' && <Brain className="mr-2 h-5 w-5 text-purple-500" />}
            {response.type === 'help' && <Search className="mr-2 h-5 w-5 text-gray-500" />}
            Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-md mb-4">{response.message}</p>
          
          {/* AI Analysis display */}
          {response.analysis && (
            <div className="my-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h3 className="font-medium text-purple-800 mb-2 flex items-center">
                <Brain className="mr-2 h-4 w-4" /> AI Analysis
              </h3>
              <div className="prose prose-sm max-w-none">
                {response.analysis.split('\n').map((line, i) => (
                  <p key={i} className="my-1">{line}</p>
                ))}
              </div>
            </div>
          )}
          
          {/* Data table */}
          {response.data && Array.isArray(response.data) && (
            <div>
              {renderDataTable(response.data)}
              
              {/* AI Analysis button */}
              {response.data.length > 0 && !response.analysis && (
                <Button 
                  variant="outline"
                  className="mt-4"
                  onClick={analyzeWithAI}
                  disabled={aiLoading}
                >
                  {aiLoading ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analyzing...</>
                  ) : (
                    <><Brain className="mr-2 h-4 w-4" /> Analyze with AI</>
                  )}
                </Button>
              )}
            </div>
          )}
          
          {/* Non-array data */}
          {response.data && !Array.isArray(response.data) && (
            <pre className="bg-gray-100 p-3 rounded-lg overflow-auto text-xs">
              {JSON.stringify(response.data, null, 2)}
            </pre>
          )}
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="w-full max-w-3xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Query Your Data</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask about your data (e.g., 'Show Facebook ads performance')"
                className="pr-10"
              />
              <Button 
                type="submit" 
                disabled={loading} 
                className="absolute right-0 top-0 h-full px-3"
                variant="ghost"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </form>
          
          <div className="mt-4">
            <p className="text-sm text-gray-500 mb-2">Try these queries:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQueries.map((q, i) => (
                <Button 
                  key={i} 
                  variant="outline" 
                  size="sm" 
                  onClick={() => handleSuggestedQuery(q)}
                  disabled={loading}
                >
                  {q}
                </Button>
              ))}
            </div>
          </div>
          
          {renderResponse()}
        </CardContent>
      </Card>
    </div>
  )
} 