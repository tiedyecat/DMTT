import { AppError } from './errors';

export async function notifyError(error: AppError): Promise<boolean> {
  try {
    // If no webhook URL is configured, just log the error
    if (!process.env.GOOGLE_CHAT_WEBHOOK_URL) {
      console.error('Error notification (webhook not configured):', error.toJSON());
      return true;
    }

    // Send error to Google Chat webhook
    const response = await fetch(process.env.GOOGLE_CHAT_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: `🚨 Error Notification\n\n*Message:* ${error.message}\n*Code:* ${error.code}\n*Status:* ${error.statusCode}\n*Time:* ${error.timestamp}\n\n*Context:*\n\`\`\`json\n${JSON.stringify(error.context, null, 2)}\n\`\`\``
      })
    });

    if (!response.ok) {
      console.error('Failed to send error notification:', await response.text());
      return false;
    }

    return true;
  } catch (err) {
    console.error('Error sending notification:', err);
    return false;
  }
} 