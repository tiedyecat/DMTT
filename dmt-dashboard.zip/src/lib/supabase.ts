import { createClient as createSupabaseClient } from '@supabase/supabase-js';

// Log environment variable status (without exposing values)
console.log('Supabase environment check:', {
  hasUrl: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
  hasKey: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  urlLength: process.env.NEXT_PUBLIC_SUPABASE_URL?.length,
  keyLength: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length
});

// Check if Supabase environment variables are set
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl) {
  console.error('CRITICAL ERROR: Missing NEXT_PUBLIC_SUPABASE_URL environment variable');
}
if (!supabaseKey) {
  console.error('CRITICAL ERROR: Missing NEXT_PUBLIC_SUPABASE_ANON_KEY environment variable');
}

export const createClient = () => {
  if (!supabaseUrl || !supabaseKey) {
    console.error('Unable to create Supabase client: Missing environment variables');
    throw new Error('Missing Supabase credentials. Please check your Vercel environment variables.');
  }

  try {
    const client = createSupabaseClient(
      supabaseUrl,
      supabaseKey,
      {
        auth: {
          persistSession: false
        }
      }
    );
    return client;
  } catch (error) {
    console.error('Error creating Supabase client:', error);
    throw new Error(`Failed to initialize Supabase client: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

let hasExecSqlFunction: boolean | null = null;

/**
 * Checks if the exec_sql function is available in the Supabase project
 * This helps determine if we can run SQL queries directly
 */
export const checkExecSqlAvailability = async () => {
  if (hasExecSqlFunction !== null) {
    return hasExecSqlFunction;
  }
  
  try {
    const supabase = createClient();
    const { data, error } = await supabase
      .rpc('exec_sql', { 
        sql: `SELECT 1 as test`
      });
      
    if (error) {
      console.error('exec_sql function not available:', error);
      hasExecSqlFunction = false;
      return false;
    }
    
    console.log('exec_sql function is available');
    hasExecSqlFunction = true;
    return true;
  } catch (err) {
    console.error('Error checking exec_sql availability:', err);
    hasExecSqlFunction = false;
    return false;
  }
};

/**
 * Test Supabase connection by attempting a simple query
 * @returns Object with connection status information
 */
export const testSupabaseConnection = async () => {
  try {
    const startTime = Date.now();
    const supabase = createClient();
    
    // Try a simple query to test connection
    const { data, error } = await supabase.from('pg_tables')
      .select('schemaname,tablename')
      .eq('schemaname', 'public')
      .limit(1);
    
    const responseTime = Date.now() - startTime;
    
    if (error) {
      console.error('Supabase connection test failed:', error);
      return {
        success: false,
        error: error.message,
        code: error.code,
        details: error.details,
        responseTime
      };
    }
    
    return {
      success: true,
      tables: data || [],
      responseTime,
      message: `Connection successful. Response time: ${responseTime}ms`
    };
  } catch (error) {
    console.error('Error testing Supabase connection:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: -1
    };
  }
};

// Service role client for administrative tasks
export const createServiceClient = () => {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    console.error('Unable to create Supabase service client: Missing environment variables');
    throw new Error('Missing Supabase service role credentials. Please check your environment variables.');
  }

  try {
    const client = createSupabaseClient(
      supabaseUrl,
      serviceRoleKey,
      {
        auth: {
          persistSession: false,
          autoRefreshToken: false
        }
      }
    );
    return client;
  } catch (error) {
    console.error('Error creating Supabase service client:', error);
    throw new Error(`Failed to initialize Supabase service client: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}; 