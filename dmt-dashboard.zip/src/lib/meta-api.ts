import { createClient } from '@supabase/supabase-js';
import axios from 'axios';

// Types
interface MetaAction {
  action_type: string;
  value: string;
  action_target_id?: string;
}

interface MetaAdInsight {
  ad_id: string;
  date_start: string;
  date_stop: string;
  impressions: string;
  reach: string;
  clicks: string;
  ctr: string;
  spend: string;
  actions?: MetaAction[];
}

interface ProcessedAdData {
  platform: string;
  ad_id: string;
  date_range: string;
  impressions: number;
  reach: number;
  clicks: number;
  spend: number;
  ctr: number;
  cpm: number;
  cpc: number;
  leads: number;
  purchases: number;
  cpl: number;
  cpp: number;
  [key: string]: any; // For custom conversion fields
}

// Custom Conversions Map
const CUSTOM_CONVERSIONS: { [key: string]: string } = {
  "1303318332892874": "keizer_sa_sign_up",
  "1622613281250293": "physiq_sync_acquire_lead",
  "1303301151575935": "salem_sa_sign_up",
  "626817764433141":  "physiq_website_form_submission",
  "122528708402051":  "lancaster_sa_sign_up",
  "1265364401998883": "albany_sa_sign_up",
  "172684631905198":  "downtown_sa_sign_up"
};

export class MetaAPI {
  private supabase;
  private accessToken: string;
  private adAccountId: string;
  private apiVersion: string;

  constructor(
    supabaseUrl: string,
    supabaseKey: string,
    metaAccessToken: string,
    adAccountId: string,
    apiVersion: string = "v22.0"
  ) {
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase credentials');
    }
    if (!metaAccessToken) {
      throw new Error('Missing Meta access token');
    }
    if (!adAccountId) {
      throw new Error('Missing Ad Account ID');
    }

    this.supabase = createClient(supabaseUrl, supabaseKey);
    this.accessToken = metaAccessToken;
    this.adAccountId = adAccountId;
    this.apiVersion = apiVersion;
  }

  async fetchInsights(datePreset: string = 'last_30d', timeIncrement: number = 1): Promise<ProcessedAdData[]> {
    try {
      console.log(`📊 Fetching Meta Ads insights for account ${this.adAccountId}...`);
      
      const response = await axios.get(
        `https://graph.facebook.com/${this.apiVersion}/${this.adAccountId}/insights`,
        {
          params: {
            access_token: this.accessToken,
            fields: "date_start,date_stop,ad_id,impressions,reach,clicks,ctr,spend,actions",
            level: "ad",
            date_preset: datePreset,
            time_increment: timeIncrement
          }
        }
      );

      console.log(`📊 Received data for ${response.data.data?.length || 0} ads`);

      if (!response.data.data || response.data.data.length === 0) {
        console.log("No data returned from Meta API");
        return [];
      }

      return this.processAdsData(response.data.data);
    } catch (error) {
      console.error("❌ Error fetching Meta insights:", error);
      throw error;
    }
  }

  private processAdsData(rawData: MetaAdInsight[]): ProcessedAdData[] {
    return rawData.map(ad => {
      // Validate required fields
      this.validateAdData(ad);
      
      const impressions = parseInt(ad.impressions) || 0;
      const clicks = parseInt(ad.clicks) || 0;
      const spend = parseFloat(ad.spend) || 0;
      const ctr = parseFloat(ad.ctr) || 0;
      const cpm = impressions > 0 ? (spend / impressions) * 1000 : 0;
      const cpc = clicks > 0 ? spend / clicks : 0;
      
      // Process standard events
      const leadsValue = ad.actions?.find(a => a.action_type === "lead")?.value || "0";
      const purchasesValue = ad.actions?.find(a => a.action_type === "purchase")?.value || "0";
      const leads = parseInt(leadsValue);
      const purchases = parseInt(purchasesValue);
      
      // Compute cost metrics
      const cpl = leads > 0 ? spend / leads : 0;
      const cpp = purchases > 0 ? spend / purchases : 0;
      
      // Process custom conversions
      const customCounts = this.processCustomConversions(ad.actions || []);
      
      return {
        platform: "Meta",
        ad_id: ad.ad_id,
        date_range: `${ad.date_start} - ${ad.date_stop}`,
        impressions,
        reach: parseInt(ad.reach) || 0,
        clicks,
        spend,
        ctr,
        cpm,
        cpc,
        leads,
        purchases,
        cpl,
        cpp,
        ...customCounts
      };
    });
  }

  private validateAdData(ad: MetaAdInsight): void {
    if (!ad.ad_id) {
      console.error("Missing ad_id for insight:", ad);
    }
    if (!ad.date_start || !ad.date_stop) {
      console.error("Missing date_start or date_stop for ad:", ad.ad_id);
    }
    if (!ad.impressions) {
      console.warn("No impressions found for ad:", ad.ad_id);
    }
    if (!ad.spend) {
      console.warn("No spend found for ad:", ad.ad_id);
    }
  }

  private processCustomConversions(actions: MetaAction[]): { [key: string]: number } {
    const customCounts: { [key: string]: number } = {};
    
    // Initialize all custom conversion counts as 0
    Object.values(CUSTOM_CONVERSIONS).forEach(colName => {
      customCounts[colName] = 0;
    });
    
    // Process actions with matching target IDs
    actions.forEach(action => {
      if (action.action_target_id && CUSTOM_CONVERSIONS[action.action_target_id]) {
        const colName = CUSTOM_CONVERSIONS[action.action_target_id];
        customCounts[colName] += parseInt(action.value) || 0;
      }
    });
    
    return customCounts;
  }

  async saveToSupabase(data: ProcessedAdData[]): Promise<{ success: boolean; error?: any }> {
    try {
      if (!data.length) {
        console.log("No data to save to Supabase");
        return { success: true };
      }

      const { data: insertedData, error } = await this.supabase
        .from("ad_data")
        .insert(data)
        .select("*");

      if (error) {
        console.error("❌ Supabase Insert Error:", error);
        return { success: false, error };
      }

      console.log(`✅ Successfully saved ${insertedData.length} records to Supabase`);
      return { success: true };
    } catch (error) {
      console.error("❌ Error saving to Supabase:", error);
      return { success: false, error };
    }
  }
} 