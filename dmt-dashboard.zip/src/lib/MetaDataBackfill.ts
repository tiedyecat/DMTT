import { MetaAPI } from './MetaAPI';
import { createClient } from '@supabase/supabase-js';

interface DateRange {
  since: string;
  until: string;
  label: string;
}

interface BackfillError {
  range: string;
  error: string;
  timestamp: string;
  details?: any;
}

interface BackfillResult {
  success: boolean;
  errors: BackfillError[];
  data: { [key: string]: any };
  allTimeStats?: {
    firstDataDate: string;
    lastDataDate: string;
    totalSpend: number;
    totalImpressions: number;
    totalClicks: number;
    totalConversions: number;
  };
}

interface MetaAccount {
  id: string;
  created_time?: string;
  name?: string;
}

export class MetaDataBackfill {
  private metaApi: MetaAPI;
  private supabase;
  private readonly BACKFILL_RANGES: DateRange[] = [
    { label: '7d', since: '-7 days', until: 'today' },
    { label: '14d', since: '-14 days', until: '-8 days' },
    { label: '28d', since: '-28 days', until: '-15 days' },
    { label: '30d', since: '-30 days', until: '-29 days' },
    { label: '60d', since: '-60 days', until: '-31 days' },
    { label: '90d', since: '-90 days', until: '-61 days' },
    { label: '180d', since: '-180 days', until: '-91 days' },
    { label: 'Q1', since: 'Q1 start', until: 'Q1 end' },
    { label: 'Q2', since: 'Q2 start', until: 'Q2 end' },
    { label: 'Q3', since: 'Q3 start', until: 'Q3 end' },
    { label: 'Q4', since: 'Q4 start', until: 'Q4 end' },
    { label: '1y', since: '-365 days', until: '-181 days' }
  ];

  constructor(accessToken: string, supabaseUrl: string, supabaseKey: string) {
    console.log('Initializing MetaDataBackfill...');
    try {
      this.metaApi = new MetaAPI(accessToken);
      this.supabase = createClient(supabaseUrl, supabaseKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false
        },
        db: {
          schema: 'public'
        }
      });
      console.log('MetaDataBackfill initialized successfully');
    } catch (error) {
      console.error('Error initializing MetaDataBackfill:', error);
      throw error;
    }
  }

  private getDateFromRelative(dateStr: string): string {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1-12
    const currentQuarter = Math.ceil(currentMonth / 3);
    
    // Handle quarterly dates - use previous year's quarters if current year's haven't happened yet
    if (dateStr.startsWith('Q')) {
      const quarter = parseInt(dateStr[1]);
      const yearToUse = quarter > currentQuarter ? currentYear - 1 : currentYear;
      
      switch(quarter) {
        case 1:
          return `${yearToUse}-01-01`;
        case 2:
          return `${yearToUse}-04-01`;
        case 3:
          return `${yearToUse}-07-01`;
        case 4:
          return `${yearToUse}-10-01`;
        default:
          throw new Error(`Invalid quarter: ${quarter}`);
      }
    }
    
    // Handle relative dates
    if (dateStr === 'today') {
      return now.toISOString().split('T')[0];
    }
    
    const match = dateStr.match(/^-(\d+) days$/);
    if (match) {
      const daysAgo = parseInt(match[1]);
      const date = new Date(now);
      date.setDate(date.getDate() - daysAgo);
      return date.toISOString().split('T')[0];
    }
    
    throw new Error(`Invalid date format: ${dateStr}`);
  }

  private getDateRangeEnd(startDate: string, rangeLabel: string): string {
    const start = new Date(startDate);
    const now = new Date();
    
    // For quarters, calculate end date
    if (rangeLabel.startsWith('Q')) {
      const quarter = parseInt(rangeLabel[1]);
      const year = start.getFullYear();
      
      switch(quarter) {
        case 1:
          return `${year}-03-31`;
        case 2:
          return `${year}-06-30`;
        case 3:
          return `${year}-09-30`;
        case 4:
          return `${year}-12-31`;
        default:
          throw new Error(`Invalid quarter: ${quarter}`);
      }
    }
    
    // For other ranges, use the 'until' date from BACKFILL_RANGES
    const range = this.BACKFILL_RANGES.find(r => r.label === rangeLabel);
    if (!range) {
      throw new Error(`Invalid range label: ${rangeLabel}`);
    }
    
    if (range.until === 'today') {
      return now.toISOString().split('T')[0];
    }
    
    const match = range.until.match(/^-(\d+) days$/);
    if (match) {
      const daysAgo = parseInt(match[1]);
      const date = new Date(now);
      date.setDate(date.getDate() - daysAgo);
      // Don't return future dates
      return date > now ? now.toISOString().split('T')[0] : date.toISOString().split('T')[0];
    }
    
    throw new Error(`Invalid date format in range: ${range.until}`);
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async persistData(accountId: string, range: string, data: any): Promise<void> {
    console.log(`Persisting data for account ${accountId}, range ${range}`);
    try {
      const { error } = await this.supabase
        .from('meta_historical_data')
        .upsert({
          account_id: accountId,
          range_label: range,
          data: data,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'account_id,range_label'
        });

      if (error) {
        console.error('Supabase error persisting data:', error);
        throw error;
      }
      console.log(`Successfully persisted data for range ${range}`);
    } catch (error) {
      console.error(`Error persisting data for range ${range}:`, error);
      throw error;
    }
  }

  private async fetchAllTimeData(accountId: string): Promise<any> {
    try {
      // First, get the account creation date
      const accountInfo = await this.metaApi.getAccounts();
      const account = accountInfo.data.find((acc: MetaAccount) => acc.id === accountId);
      if (!account) throw new Error('Account not found');

      const startDate = account.created_time?.split('T')[0] || '2010-01-01'; // Fallback to 2010
      const endDate = new Date().toISOString().split('T')[0];

      // Fetch data in 90-day chunks to avoid timeouts
      const chunks: any[] = [];
      let currentStart = new Date(startDate);
      const end = new Date(endDate);

      while (currentStart < end) {
        let chunkEnd = new Date(currentStart);
        chunkEnd.setDate(chunkEnd.getDate() + 90);
        if (chunkEnd > end) chunkEnd = end;

        await this.delay(2000); // Respect rate limits

        try {
          const data = await this.metaApi.getCustomInsights(
            accountId,
            currentStart.toISOString().split('T')[0],
            chunkEnd.toISOString().split('T')[0],
            ['spend', 'impressions', 'clicks', 'conversions', 'ctr', 'cpc', 'cpm']
          );
          chunks.push(data);
        } catch (error) {
          console.error(`Error fetching chunk ${currentStart} to ${chunkEnd}:`, error);
          // Continue to next chunk even if this one fails
        }

        currentStart = chunkEnd;
      }

      // Aggregate all-time stats
      const allTimeStats = chunks.reduce((acc, chunk) => {
        if (!chunk?.data) return acc;
        chunk.data.forEach((day: any) => {
          acc.totalSpend += parseFloat(day.spend || '0');
          acc.totalImpressions += parseInt(day.impressions || '0');
          acc.totalClicks += parseInt(day.clicks || '0');
          acc.totalConversions += parseInt(day.conversions?.[0]?.value || '0');
        });
        return acc;
      }, {
        firstDataDate: startDate,
        lastDataDate: endDate,
        totalSpend: 0,
        totalImpressions: 0,
        totalClicks: 0,
        totalConversions: 0
      });

      return { chunks, allTimeStats };
    } catch (error) {
      console.error('Error fetching all-time data:', error);
      return null;
    }
  }

  private async ensureTableExists(): Promise<void> {
    try {
      // Check if table exists
      const { data, error } = await this.supabase
        .from('meta_historical_data')
        .select('count')
        .limit(1);

      if (error && error.code === '42P01') { // Table doesn't exist
        console.log('Creating meta_historical_data table...');
        
        // Create table without RLS first
        await this.supabase.from('meta_historical_data').insert({
          account_id: 'test',
          range_label: 'test',
          data: {},
          updated_at: new Date().toISOString()
        });

        console.log('Table created successfully');
      } else if (error) {
        console.error('Error checking table:', error);
        throw error;
      }
    } catch (error) {
      console.error('Error in ensureTableExists:', error);
      throw error;
    }
  }

  async backfillData(
    accountId: string,
    onProgress?: (range: DateRange, data: any, error?: string) => void
  ): Promise<BackfillResult> {
    console.log(`Starting backfill for account ${accountId}`);
    const results: { [key: string]: any } = {};
    const errors: BackfillError[] = [];

    // Ensure table exists
    try {
      await this.ensureTableExists();
    } catch (error) {
      console.error('Failed to ensure table exists:', error);
      throw error;
    }

    // Test Supabase connection first
    try {
      const { error } = await this.supabase.from('meta_historical_data').select('count').limit(1);
      if (error) {
        console.error('Supabase connection test failed:', error);
        throw new Error(`Supabase connection failed: ${error.message}`);
      }
      console.log('Supabase connection test successful');
    } catch (error) {
      console.error('Error testing Supabase connection:', error);
      throw error;
    }

    // Process each date range
    for (const range of this.BACKFILL_RANGES) {
      try {
        console.log(`Processing range: ${range.label}`);
        await this.delay(2000); // Respect rate limits

        const startDate = this.getDateFromRelative(range.since);
        const endDate = this.getDateRangeEnd(startDate, range.label);
        
        // Skip if start date is in the future
        const now = new Date();
        const start = new Date(startDate);
        if (start > now) {
          console.log(`Skipping future date range ${range.label}: ${startDate} to ${endDate}`);
          continue;
        }

        console.log(`Fetching data for range ${range.label}: ${startDate} to ${endDate}`);
        const data = await this.metaApi.getCustomInsights(
          accountId,
          startDate,
          endDate,
          ['spend', 'impressions', 'clicks', 'conversions', 'ctr', 'cpc', 'cpm']
        );

        results[range.label] = data;
        await this.persistData(accountId, range.label, data);
        onProgress?.(range, data);
        console.log(`Successfully processed range ${range.label}`);
      } catch (error: any) {
        console.error(`Error processing range ${range.label}:`, error);
        const errorDetails = {
          range: range.label,
          error: error.message,
          timestamp: new Date().toISOString(),
          details: error.response?.data
        };
        errors.push(errorDetails);
        onProgress?.(range, null, error.message);
      }
    }

    return {
      success: errors.length === 0,
      errors,
      data: results,
      allTimeStats: await this.fetchAllTimeData(accountId)
    };
  }
} 