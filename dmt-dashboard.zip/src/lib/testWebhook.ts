import { AppError } from './errors';
import { notifyError } from './errorNotifications';

export async function testWebhook() {
  const error = new AppError({
    message: 'Test error notification',
    statusCode: 500,
    code: 'TEST_ERROR',
    context: {
      testId: 'test-123',
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      testData: {
        sample: 'data',
        value: 42
      }
    }
  });

  const result = await notifyError(error);
  console.log('Webhook test result:', result);
  return result;
} 