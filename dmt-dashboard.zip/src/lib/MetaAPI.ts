import axios, {
  type AxiosInstance,
  type AxiosError,
  type AxiosRequestConfig,
  type AxiosResponse
} from 'axios';

// Interfaces for API responses and data structures
interface MetaAccount {
  id: string;
  name: string;
  status: string;
}

interface Campaign {
  id: string;
  name: string;
  status: string;
  objective: string;
}

interface AdSet {
  id: string;
  name: string;
  status: string;
  campaign_id: string;
  daily_budget: number;
}

interface Ad {
  id: string;
  name: string;
  status: string;
  adset_id: string;
  creative: {
    id: string;
    title?: string;
    body?: string;
  };
}

interface Insight {
  date_start: string;
  date_stop: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  cpc: number;
  cpm: number;
}

interface APIError {
  message: string;
  type: string;
  code: number;
}

interface MetaResponse<T> {
  data: T;
  error?: APIError;
}

// Simple in-memory cache implementation
interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

interface RateLimitInfo {
  lastRequest: number;
  count: number;
}

export class MetaAPI {
  private api: AxiosInstance;
  private cache: Map<string, CacheEntry<any>> = new Map();
  private rateLimit: Map<string, RateLimitInfo> = new Map();
  private readonly CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  private readonly RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
  private readonly MAX_REQUESTS_PER_WINDOW = 200; // Meta's rate limit is ~200/minute
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 1000; // 1 second

  constructor(accessToken: string) {
    this.api = axios.create({
      baseURL: 'https://graph.facebook.com/v18.0',
      timeout: 10000,
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      }
    });

    // Add interceptors for error handling and token protection
    this.api.interceptors.response.use(
      (res: AxiosResponse) => res,
      (err: AxiosError) => {
        // Remove sensitive data from logs
        if (err.config) delete err.config.headers?.Authorization;
        return Promise.reject(err);
      }
    );
  }

  private getCacheKey(endpoint: string, params?: any): string {
    return `${endpoint}:${JSON.stringify(params || {})}`;
  }

  private getCachedData<T>(key: string): T | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    // Check if cache is still valid
    if (Date.now() - entry.timestamp > this.CACHE_TTL) {
      this.cache.delete(key);
      return null;
    }

    return entry.data;
  }

  private setCachedData<T>(key: string, data: T): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  private async checkRateLimit(endpoint: string): Promise<void> {
    const now = Date.now();
    const info = this.rateLimit.get(endpoint) || { lastRequest: 0, count: 0 };

    // Reset counter if we're in a new window
    if (now - info.lastRequest > this.RATE_LIMIT_WINDOW) {
      info.count = 0;
    }

    if (info.count >= this.MAX_REQUESTS_PER_WINDOW) {
      const waitTime = this.RATE_LIMIT_WINDOW - (now - info.lastRequest);
      await new Promise(resolve => setTimeout(resolve, waitTime));
      info.count = 0;
    }

    info.lastRequest = now;
    info.count++;
    this.rateLimit.set(endpoint, info);
  }

  private async retryRequest<T>(
    config: AxiosRequestConfig,
    retries: number = 0
  ): Promise<T> {
    try {
      const response = await this.api.request<T>(config);
      return response.data;
    } catch (error) {
      const err = error as AxiosError;
      
      // Don't retry on certain errors
      if (
        err.response?.status === 401 || // Unauthorized
        err.response?.status === 403 || // Forbidden
        err.response?.status === 404 || // Not found
        retries >= this.MAX_RETRIES
      ) {
        throw error;
      }

      // Exponential backoff
      const delay = this.RETRY_DELAY * Math.pow(2, retries);
      await new Promise(resolve => setTimeout(resolve, delay));
      
      return this.retryRequest<T>(config, retries + 1);
    }
  }

  private async makeRequest<T>(
    endpoint: string,
    config: AxiosRequestConfig,
    useCache: boolean = true
  ): Promise<T> {
    const cacheKey = this.getCacheKey(endpoint, config.params);
    
    // Check cache first
    if (useCache) {
      const cachedData = this.getCachedData<T>(cacheKey);
      if (cachedData) return cachedData;
    }

    // Check rate limit
    await this.checkRateLimit(endpoint);

    // Make request with retry logic
    const data = await this.retryRequest<T>({
      ...config,
      url: endpoint
    });

    // Cache the result
    if (useCache) {
      this.setCachedData(cacheKey, data);
    }

    return data;
  }

  async getAccounts(): Promise<MetaResponse<any>> {
    return this.makeRequest<MetaResponse<any>>('/me/adaccounts', {
      params: {
        fields: 'id,name,status',
      },
    });
  }

  async getCampaigns(
    accountId: string,
    startDate?: string,
    endDate?: string
  ): Promise<MetaResponse<any>> {
    const formattedAccountId = this.formatAccountId(accountId);
    
    const params: any = {
      fields: 'id,name,status,objective,start_time,end_time,daily_budget,lifetime_budget,bid_strategy,campaign_id',
    };

    // Add date filtering if provided
    if (startDate || endDate) {
      const timeRange = {
        since: startDate,
        until: endDate
      };

      if (startDate && !this.validateDateFormat(startDate)) {
        throw new Error('Invalid start_date format. Use YYYY-MM-DD');
      }
      if (endDate && !this.validateDateFormat(endDate)) {
        throw new Error('Invalid end_date format. Use YYYY-MM-DD');
      }

      params.time_range = JSON.stringify(timeRange);
    }

    return this.makeRequest<MetaResponse<any>>(
      `/${formattedAccountId}/campaigns`,
      { params }
    );
  }

  async getAdSets(accountId: string): Promise<MetaResponse<any>> {
    const formattedAccountId = this.formatAccountId(accountId);
    return this.makeRequest<MetaResponse<any>>(`/${formattedAccountId}/adsets`, {
      params: {
        fields: 'id,name,status,campaign_id,daily_budget',
      },
    });
  }

  async getAds(accountId: string): Promise<MetaResponse<any>> {
    const formattedAccountId = this.formatAccountId(accountId);
    return this.makeRequest<MetaResponse<any>>(`/${formattedAccountId}/ads`, {
      params: {
        fields: 'id,name,status,adset_id,creative{id,title,body}',
      },
    });
  }

  async getInsights(
    accountId: string,
    datePreset: 'today' | 'yesterday' | 'last_7d' | 'last_30d' = 'last_7d'
  ): Promise<MetaResponse<any>> {
    const formattedAccountId = this.formatAccountId(accountId);
    return this.makeRequest<MetaResponse<any>>(
      `/${formattedAccountId}/insights`,
      {
        params: {
          date_preset: datePreset,
          fields: 'date_start,date_stop,spend,impressions,clicks,conversions,ctr,cpc,cpm',
        },
      },
      false // Don't cache insights as they change frequently
    );
  }

  async getCustomInsights(
    accountId: string,
    startDate: string,
    endDate: string,
    fields: string[] = ['spend', 'impressions', 'clicks', 'conversions']
  ): Promise<MetaResponse<any>> {
    if (!this.validateDateFormat(startDate) || !this.validateDateFormat(endDate)) {
      throw new Error('Invalid date format. Use YYYY-MM-DD');
    }

    const formattedAccountId = this.formatAccountId(accountId);
    return this.makeRequest<MetaResponse<any>>(
      `/${formattedAccountId}/insights`,
      {
        params: {
          time_range: JSON.stringify({
            since: startDate,
            until: endDate,
          }),
          fields: fields.join(','),
        },
      },
      false // Don't cache custom insights
    );
  }

  private validateDateFormat(date: string): boolean {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    return dateRegex.test(date);
  }

  private formatAccountId(accountId: string): string {
    return accountId.startsWith('act_') ? accountId : `act_${accountId}`;
  }
} 