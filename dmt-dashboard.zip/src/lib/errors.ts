interface ErrorContext {
  [key: string]: unknown;
}

interface AppErrorOptions {
  message: string;
  statusCode?: number;
  code?: string;
  context?: ErrorContext;
}

export class AppError extends Error {
  statusCode: number;
  code: string;
  context?: ErrorContext;
  timestamp: string;

  constructor(options: AppErrorOptions) {
    super(options.message);
    this.name = 'AppError';
    this.statusCode = options.statusCode || 500;
    this.code = options.code || 'INTERNAL_SERVER_ERROR';
    this.context = options.context;
    this.timestamp = new Date().toISOString();

    // Ensure proper prototype chain for instanceof checks
    Object.setPrototypeOf(this, AppError.prototype);
  }

  toJSON() {
    return {
      message: this.message,
      statusCode: this.statusCode,
      code: this.code,
      context: this.context,
      timestamp: this.timestamp
    };
  }
} 