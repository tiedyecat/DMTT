// Mock data for database tables and views

// Interface definitions for typed data
interface Column {
  name: string;
  type: string;
  is_nullable: boolean;
}

interface PrimaryKey {
  name: string;
  column_names: string[];
}

interface Index {
  name: string;
  column_names: string[];
  is_unique: boolean;
}

interface TableInfo {
  name: string;
  type: string;
  columns: Column[];
  primary_keys: PrimaryKey[];
  indexes: Index[];
}

interface View {
  name: string;
  definition: string;
  columns: Column[];
}

interface SchemaData {
  tables: TableInfo[];
}

interface ViewsData {
  views: View[];
}

// Mock data for database tables
export function getFormattedSchemaData(): SchemaData {
  return {
    tables: [
      {
        name: "ai_flags_log",
        type: "table",
        columns: [
          { name: "id", type: "uuid", is_nullable: false },
          { name: "user_id", type: "text", is_nullable: true },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "flag_type", type: "text", is_nullable: true },
          { name: "flag_data", type: "jsonb", is_nullable: true },
          { name: "created_at", type: "timestamp with time zone", is_nullable: true }
        ],
        primary_keys: [
          { name: "ai_flags_log_pkey", column_names: ["id"] }
        ],
        indexes: [
          { name: "ai_flags_log_pkey", column_names: ["id"], is_unique: true }
        ]
      },
      {
        name: "ai_summaries",
        type: "table",
        columns: [
          { name: "id", type: "uuid", is_nullable: false },
          { name: "user_id", type: "text", is_nullable: true },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "summary_text", type: "text", is_nullable: true },
          { name: "summary_type", type: "text", is_nullable: true },
          { name: "created_at", type: "timestamp with time zone", is_nullable: true },
          { name: "summary_meta", type: "jsonb", is_nullable: true }
        ],
        primary_keys: [
          { name: "ai_summaries_pkey", column_names: ["id"] }
        ],
        indexes: [
          { name: "ai_summaries_pkey", column_names: ["id"], is_unique: true }
        ]
      },
      {
        name: "alert_high_cpa",
        type: "table",
        columns: [
          { name: "id", type: "uuid", is_nullable: false },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "campaign_id", type: "text", is_nullable: true },
          { name: "campaign_name", type: "text", is_nullable: true },
          { name: "adset_id", type: "text", is_nullable: true },
          { name: "adset_name", type: "text", is_nullable: true },
          { name: "objective", type: "text", is_nullable: true },
          { name: "cpa", type: "double precision", is_nullable: true },
          { name: "cpa_threshold", type: "double precision", is_nullable: true },
          { name: "spend", type: "double precision", is_nullable: true },
          { name: "created_at", type: "timestamp with time zone", is_nullable: true }
        ],
        primary_keys: [
          { name: "alert_high_cpa_pkey", column_names: ["id"] }
        ],
        indexes: [
          { name: "alert_high_cpa_pkey", column_names: ["id"], is_unique: true }
        ]
      },
      {
        name: "last_7_day_totals",
        type: "table",
        columns: [
          { name: "id", type: "uuid", is_nullable: false },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "spend", type: "double precision", is_nullable: true },
          { name: "impressions", type: "bigint", is_nullable: true },
          { name: "clicks", type: "bigint", is_nullable: true },
          { name: "conversions", type: "bigint", is_nullable: true },
          { name: "ctr", type: "double precision", is_nullable: true },
          { name: "cpc", type: "double precision", is_nullable: true },
          { name: "cpa", type: "double precision", is_nullable: true },
          { name: "cvr", type: "double precision", is_nullable: true },
          { name: "created_at", type: "timestamp with time zone", is_nullable: true }
        ],
        primary_keys: [
          { name: "last_7_day_totals_pkey", column_names: ["id"] }
        ],
        indexes: [
          { name: "last_7_day_totals_pkey", column_names: ["id"], is_unique: true }
        ]
      },
      {
        name: "meta_accounts",
        type: "table",
        columns: [
          { name: "id", type: "uuid", is_nullable: false },
          { name: "account_id", type: "text", is_nullable: true },
          { name: "account_name", type: "text", is_nullable: true },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "created_at", type: "timestamp with time zone", is_nullable: true }
        ],
        primary_keys: [
          { name: "meta_accounts_pkey", column_names: ["id"] }
        ],
        indexes: [
          { name: "meta_accounts_pkey", column_names: ["id"], is_unique: true }
        ]
      }
    ]
  };
}

// Mock data for database views
export function getFormattedViewsData(): ViewsData {
  return {
    views: [
      {
        name: "daily_performance_view",
        definition: "SELECT date_trunc('day'::text, ma.date) AS day, ma.business_id, sum(ma.spend) AS spend, sum(ma.impressions) AS impressions, sum(ma.clicks) AS clicks, sum(ma.conversions) AS conversions, CASE WHEN sum(ma.impressions) > 0::numeric THEN sum(ma.clicks) / sum(ma.impressions)::double precision ELSE 0::double precision END AS ctr, CASE WHEN sum(ma.clicks) > 0::numeric THEN sum(ma.spend) / sum(ma.clicks)::double precision ELSE 0::double precision END AS cpc, CASE WHEN sum(ma.conversions) > 0::numeric THEN sum(ma.spend) / sum(ma.conversions)::double precision ELSE 0::double precision END AS cpa, CASE WHEN sum(ma.clicks) > 0::numeric THEN sum(ma.conversions) / sum(ma.clicks)::double precision ELSE 0::double precision END AS cvr FROM meta_ad_insights ma GROUP BY (date_trunc('day'::text, ma.date)), ma.business_id ORDER BY (date_trunc('day'::text, ma.date)) DESC;",
        columns: [
          { name: "day", type: "timestamp without time zone", is_nullable: true },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "spend", type: "numeric", is_nullable: true },
          { name: "impressions", type: "numeric", is_nullable: true },
          { name: "clicks", type: "numeric", is_nullable: true },
          { name: "conversions", type: "numeric", is_nullable: true },
          { name: "ctr", type: "double precision", is_nullable: true },
          { name: "cpc", type: "double precision", is_nullable: true },
          { name: "cpa", type: "double precision", is_nullable: true },
          { name: "cvr", type: "double precision", is_nullable: true }
        ]
      },
      {
        name: "campaign_performance_view",
        definition: "SELECT c.campaign_id, c.campaign_name, c.objective, date_trunc('day'::text, ma.date) AS day, ma.business_id, sum(ma.spend) AS spend, sum(ma.impressions) AS impressions, sum(ma.clicks) AS clicks, sum(ma.conversions) AS conversions, CASE WHEN sum(ma.impressions) > 0::numeric THEN sum(ma.clicks) / sum(ma.impressions)::double precision ELSE 0::double precision END AS ctr, CASE WHEN sum(ma.clicks) > 0::numeric THEN sum(ma.spend) / sum(ma.clicks)::double precision ELSE 0::double precision END AS cpc, CASE WHEN sum(ma.conversions) > 0::numeric THEN sum(ma.spend) / sum(ma.conversions)::double precision ELSE 0::double precision END AS cpa, CASE WHEN sum(ma.clicks) > 0::numeric THEN sum(ma.conversions) / sum(ma.clicks)::double precision ELSE 0::double precision END AS cvr FROM meta_ad_insights ma JOIN meta_campaigns c ON ma.campaign_id::text = c.campaign_id::text GROUP BY c.campaign_id, c.campaign_name, c.objective, (date_trunc('day'::text, ma.date)), ma.business_id ORDER BY (date_trunc('day'::text, ma.date)) DESC;",
        columns: [
          { name: "campaign_id", type: "text", is_nullable: true },
          { name: "campaign_name", type: "text", is_nullable: true },
          { name: "objective", type: "text", is_nullable: true },
          { name: "day", type: "timestamp without time zone", is_nullable: true },
          { name: "business_id", type: "text", is_nullable: true },
          { name: "spend", type: "numeric", is_nullable: true },
          { name: "impressions", type: "numeric", is_nullable: true },
          { name: "clicks", type: "numeric", is_nullable: true },
          { name: "conversions", type: "numeric", is_nullable: true },
          { name: "ctr", type: "double precision", is_nullable: true },
          { name: "cpc", type: "double precision", is_nullable: true },
          { name: "cpa", type: "double precision", is_nullable: true },
          { name: "cvr", type: "double precision", is_nullable: true }
        ]
      }
    ]
  };
}