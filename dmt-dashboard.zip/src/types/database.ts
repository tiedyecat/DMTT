export interface AIFlagsLog {
  id: string;
  timestamp: string;
  error_type: string;
  context: string;
  api_model_used: string;
  batch_hash: string;
}

export interface AISummary {
  id: string;
  business_name: string;
  date: string;
  summary: string;
  model: string;
  created_at: string;
}

export interface AISummaryInputReady {
  id: string;
  account_id: string;
  date: string;
  time_window: string;
  summary_payload: any; // JSONB type
  created_at: string;
}

export interface AlertConversionCrash {
  account_id: string;
  business_name: string;
  date: string;
  leads: number;
  purchases: number;
  conversions: number;
  prev_3_day_conversions: number;
}

export interface AlertCPAIncrease {
  account_id: string;
  business_name: string;
  date: string;
  cpa: number;
  avg_7d_cpa: number;
}

export interface AlertCreativeDecay {
  account_id: string;
  business_name: string;
  ad_name: string;
  campaign_id: string;
  campaign_name: string;
  date: string;
  ctr: number;
  cpa: number;
  early_ctr: number;
  recent_ctr: number;
  early_cpa: number;
  recent_cpa: number;
}

export interface AlertCTRDrop {
  account_id: string;
  date: string;
  ctr: number;
  avg_7d_ctr: number;
}

export interface AlertHighCPA {
  id: string;
  account_id: string;
  business_name: string;
  campaign_id: string;
  campaign_name: string;
  ad_id: string;
  ad_name: string;
  impressions: number;
  clicks: number;
  ctr: number;
  spend: number;
  daily_budget: number;
  cpc: number;
  cpm: number;
  frequency: number;
  conversions: number;
  cpa: number;
  date: string;
  created_at: string;
  flagged: boolean;
  flagged_reason: string;
  leads: number;
  purchases: number;
  ai_summary: string;
  preflagged: boolean;
  campaign_start_date: string;
  campaign_objective: string;
  funnel_stage: string;
  gender_targeting: string;
  age_range_targeting: string;
}

export interface AlertHighSpend {
  id: string;
  account_id: string;
  business_name: string;
  campaign_id: string;
  campaign_name: string;
  ad_id: string;
  ad_name: string;
  impressions: number;
  clicks: number;
  ctr: number;
  spend: number;
  daily_budget: number;
  cpc: number;
  cpm: number;
  frequency: number;
  conversions: number;
  cpa: number;
  date: string;
  created_at: string;
  flagged: boolean;
  flagged_reason: string;
  leads: number;
  purchases: number;
  ai_summary: string;
} 