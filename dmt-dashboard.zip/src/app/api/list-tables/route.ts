import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase';
import { getFormattedSchemaData, getFormattedViewsData } from '@/lib/mockData';

export interface Column {
  column_name: string;
  data_type: string;
  is_nullable: string;
  column_default: string | null;
  character_maximum_length: number | null;
}

export interface PrimaryKey {
  column_name: string;
}

export interface Index {
  index_name: string;
  column_name: string;
  is_unique: boolean;
}

export interface TableInfo {
  schema: string;
  name: string;
  type: string;
  columns: Column[];
  primaryKeys: PrimaryKey[];
  indexes: Index[];
  hasPrimaryKeyInfo: boolean;
  hasIndexInfo: boolean;
  error?: string;
}

export interface View {
  table_schema: string;
  table_name: string;
  view_definition: string;
}

export async function GET() {
  try {
    // Check if we should use mock data
    const useMockData = process.env.USE_MOCK_DATA === 'TRUE';
    if (useMockData) {
      console.log('Using mock data for list-tables endpoint');
      const schemaData = getFormattedSchemaData();
      const viewsData = getFormattedViewsData();
      
      return NextResponse.json({
        tables: schemaData.tables,
        views: viewsData.views,
        timestamp: new Date().toISOString(),
        source: 'Mock Data'
      });
    }
    
    console.log('Fetching real database tables and views');
    try {
      const supabase = createClient();
      
      // Query tables
      const { data: tables, error: tablesError } = await supabase
        .from('pg_tables')
        .select('schemaname,tablename')
        .eq('schemaname', 'public');
        
      if (tablesError) {
        console.error('Error fetching tables:', tablesError);
        throw tablesError;
      }
      
      // Query views
      const { data: views, error: viewsError } = await supabase
        .from('pg_views')
        .select('schemaname,viewname,definition')
        .eq('schemaname', 'public');
        
      if (viewsError) {
        console.error('Error fetching views:', viewsError);
        throw viewsError;
      }
      
      // Format tables as TableInfo[]
      const formattedTables = tables ? tables.map(table => ({
        schema: table.schemaname,
        name: table.tablename,
        type: 'TABLE',
        columns: [],
        primaryKeys: [],
        indexes: [],
        hasPrimaryKeyInfo: false,
        hasIndexInfo: false
      })) : [];
      
      // Format views as View[]
      const formattedViews = views ? views.map(view => ({
        table_schema: view.schemaname,
        table_name: view.viewname,
        view_definition: view.definition
      })) : [];
      
      return NextResponse.json({
        tables: formattedTables,
        views: formattedViews,
        timestamp: new Date().toISOString(),
        source: 'Database',
        raw: { tables, views }
      });
    } catch (dbError) {
      console.error('Database error in list-tables endpoint:', dbError);
      
      // Fall back to mock data if real DB fails
      console.log('Falling back to mock data after database error');
      const schemaData = getFormattedSchemaData();
      const viewsData = getFormattedViewsData();
      
      return NextResponse.json({
        tables: schemaData.tables,
        views: viewsData.views,
        timestamp: new Date().toISOString(),
        source: 'Mock Data (Fallback)',
        error: dbError instanceof Error ? dbError.message : 'Unknown database error',
        fallback: true
      });
    }
  } catch (error) {
    console.error('Error in list-tables endpoint:', error);
    return NextResponse.json(
      { 
        error: 'Error fetching tables and views',
        message: error instanceof Error ? error.message : 'Unknown error',
        stack: error instanceof Error ? error.stack : null
      },
      { status: 500 }
    );
  }
} 