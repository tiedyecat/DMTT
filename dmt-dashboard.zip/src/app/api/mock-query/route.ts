import { NextResponse } from 'next/server'

interface QueryRequest {
  query: string
}

// Generate mock Facebook ads data
function generateMockAdsData(count = 10) {
  const data = []
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - count)
  
  for (let i = 0; i < count; i++) {
    const date = new Date(startDate)
    date.setDate(date.getDate() + i)
    
    data.push({
      id: `ad_${i}`,
      date: date.toISOString().split('T')[0],
      campaign_name: `Campaign ${(i % 3) + 1}`,
      ad_set_name: `Ad Set ${(i % 5) + 1}`,
      platform: 'Facebook',
      spend: parseFloat((Math.random() * 100 + 50).toFixed(2)),
      impressions: Math.floor(Math.random() * 5000 + 1000),
      clicks: Math.floor(Math.random() * 200 + 20),
      ctr: parseFloat((Math.random() * 5 + 1).toFixed(2)),
      cpc: parseFloat((Math.random() * 2 + 0.5).toFixed(2)),
      conversions: Math.floor(Math.random() * 10 + 1),
      cpa: parseFloat((Math.random() * 50 + 10).toFixed(2)),
      roas: parseFloat((Math.random() * 4 + 0.5).toFixed(2))
    })
  }
  
  return data
}

// Generate mock demographics data
function generateMockDemographicsData(count = 10) {
  const data = []
  const ageRanges = ['18-24', '25-34', '35-44', '45-54', '55-64', '65+']
  const genders = ['male', 'female', 'unknown']
  
  for (let i = 0; i < count; i++) {
    data.push({
      id: `demo_${i}`,
      date: new Date().toISOString().split('T')[0],
      age_range: ageRanges[Math.floor(Math.random() * ageRanges.length)],
      gender: genders[Math.floor(Math.random() * genders.length)],
      region: `Region ${(i % 5) + 1}`,
      impressions: Math.floor(Math.random() * 10000 + 1000),
      clicks: Math.floor(Math.random() * 500 + 50),
      ctr: parseFloat((Math.random() * 8 + 1).toFixed(2)),
      spend: parseFloat((Math.random() * 200 + 50).toFixed(2)),
      conversions: Math.floor(Math.random() * 20 + 2)
    })
  }
  
  return data
}

// Generate mock alerts
function generateMockAlerts(count = 5) {
  const data = []
  const alertTypes = ['high_cpa', 'budget_depleted', 'performance_drop', 'conversion_rate_drop']
  const severities = ['high', 'medium', 'low']
  
  for (let i = 0; i < count; i++) {
    data.push({
      id: `alert_${i}`,
      created_at: new Date().toISOString(),
      alert_type: alertTypes[Math.floor(Math.random() * alertTypes.length)],
      severity: severities[Math.floor(Math.random() * severities.length)],
      campaign_name: `Campaign ${(i % 3) + 1}`,
      metric: i % 2 === 0 ? 'CPA' : 'CTR',
      current_value: parseFloat((Math.random() * 100).toFixed(2)),
      threshold_value: parseFloat((Math.random() * 80).toFixed(2)),
      message: `Alert: Unusual activity detected in Campaign ${(i % 3) + 1}`,
      is_resolved: i > count / 2
    })
  }
  
  return data
}

// Generate mock AI summaries
function generateMockAISummaries(count = 3) {
  const data = []
  
  for (let i = 0; i < count; i++) {
    data.push({
      id: `summary_${i}`,
      created_at: new Date().toISOString(),
      summary_type: i === 0 ? 'weekly_performance' : i === 1 ? 'demographic_insights' : 'campaign_recommendations',
      title: `AI Summary ${i + 1}`,
      content: `This is a mock AI-generated summary #${i + 1} containing analysis of your marketing data. It highlights key trends and provides actionable insights for improvement.`,
      metrics_included: ['spend', 'ctr', 'cpa', 'conversions'],
      date_range: 'Last 7 days'
    })
  }
  
  return data
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as QueryRequest
    const query = body.query.toLowerCase()
    
    // FACEBOOK/META ADS QUERIES
    if (query.includes('facebook') || query.includes('meta') || query.includes('ads') || query.includes('performance')) {
      // Return mock ads data
      return NextResponse.json({
        type: 'summary',
        data: generateMockAdsData(10),
        message: 'Here\'s the recent Facebook/Meta ads performance data'
      })
    }
    
    // DEMOGRAPHICS QUERIES
    if (query.includes('demographics') || query.includes('audience')) {
      // Return mock demographics data
      return NextResponse.json({
        type: 'summary',
        data: generateMockDemographicsData(8),
        message: 'Here\'s the audience demographics data from your ads'
      })
    }
    
    // FLAGS AND ALERTS QUERIES
    if (query.includes('flags') || query.includes('alerts') || query.includes('warnings')) {
      // Return mock alerts data
      return NextResponse.json({
        type: 'alert',
        data: generateMockAlerts(5),
        message: 'Here are the recent alerts and flags from your accounts'
      })
    }
    
    // AI SUMMARIES QUERIES
    if (query.includes('summary') || query.includes('summaries') || query.includes('ai insights')) {
      // Return mock AI summaries
      return NextResponse.json({
        type: 'summary',
        data: generateMockAISummaries(3),
        message: 'Here are the latest AI-generated performance summaries'
      })
    }
    
    // Default response
    return NextResponse.json({
      type: 'help',
      data: null,
      message: 'Try asking about:\n- Facebook/Meta ads performance\n- Audience demographics\n- Alerts and flags\n- AI-generated summaries'
    })
  } catch (error) {
    console.error('Error processing query:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
} 