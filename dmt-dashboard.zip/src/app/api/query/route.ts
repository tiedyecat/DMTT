import { createClient, testSupabaseConnection } from '@/lib/supabase'
import { checkExecSqlAvailability } from '@/lib/supabase'
import { NextResponse } from 'next/server'
import OpenAI from 'openai'
import { getFormattedSchemaData, getFormattedViewsData } from '@/lib/mockData'

interface QueryRequest {
  query: string
  teamMember?: string
}

// Initialize OpenAI client
let openai: OpenAI | null = null;
let openaiInitialized = false;
let openaiInitError: string | null = null;

try {
  // Check if API key is available
  if (process.env.OPENAI_API_KEY) {
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
    openaiInitialized = true;
    console.log('OpenAI client initialized');
  } else {
    openaiInitError = 'OPENAI_API_KEY not found in environment variables';
    console.warn(openaiInitError);
  }
} catch (error) {
  openaiInitError = error instanceof Error ? error.message : 'Unknown error initializing OpenAI';
  console.error('Error initializing OpenAI client:', error);
}

// Test OpenAI connectivity without using tokens
async function pingOpenAI() {
  if (!openai) {
    return {
      success: false,
      error: openaiInitError || 'OpenAI client not initialized'
    };
  }

  try {
    console.log('Testing OpenAI connectivity...');
    
    // Just check the models endpoint which doesn't consume tokens
    const models = await openai.models.list();
    console.log(`OpenAI connectivity test successful, found ${models.data.length} models`);
    
    return {
      success: true,
      message: `Connection successful. ${models.data.length} models available.`
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('OpenAI connectivity test failed:', errorMessage);
    
    if (error instanceof Error && 'status' in error) {
      console.error('HTTP Status:', (error as any).status);
    }
    
    return {
      success: false,
      error: errorMessage
    };
  }
}

// Function to process query using OpenAI - modified to not use tokens in test mode
async function processQueryWithAI(query: string, teamMember?: string, testMode = true) {
  // Check if we should use real AI responses based on environment variable
  const useRealAI = process.env.USE_REAL_AI === 'TRUE';
  
  if (useRealAI) {
    testMode = false;
    console.log('Using real AI responses (USE_REAL_AI=TRUE)');
  }

  if (!openai) {
    console.warn('OpenAI client not available');
    return {
      success: false,
      error: openaiInitError || 'OpenAI API is not configured. Please check your environment variables.'
    };
  }

  // In test mode, just ping the API without sending a real request
  if (testMode) {
    return await pingOpenAI();
  }

  try {
    console.log(`Processing query with OpenAI: "${query}"`);
    
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // Changed from gpt-4-turbo-preview to cheaper model
      messages: [
        { 
          role: "system", 
          content: "You are a helpful assistant for a marketing dashboard. The user will ask questions about marketing performance, CPA, and other metrics." 
        },
        { 
          role: "user", 
          content: `${teamMember ? `[${teamMember}]: ` : ''}${query}` 
        }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    const aiResponse = completion.choices[0]?.message?.content || 'No response from AI';
    console.log('AI response received');
    
    return {
      success: true,
      response: aiResponse
    };
  } catch (error) {
    console.error('Error calling OpenAI API:', error);
    if (error instanceof Error && 'status' in error) {
      console.error('HTTP Status:', (error as any).status);
    }
    
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred with AI processing'
    };
  }
}

// Validate that required tables exist
async function validateRequiredTables() {
  try {
    const supabase = createClient()
    const tables = ['last_7_day_totals', 'alert_high_cpa']
    const missingTables = []

    for (const table of tables) {
      // Check if table exists by trying to select 0 rows
      const { error } = await supabase
        .from(table)
        .select('*')
        .limit(0)

      if (error) {
        console.error(`Table validation error for ${table}:`, error)
        missingTables.push({
          name: table,
          error: error.message,
          code: error.code
        })
      }
    }

    return {
      valid: missingTables.length === 0,
      missingTables,
      timestamp: new Date().toISOString()
    }
  } catch (error) {
    console.error('Error validating tables:', error)
    return {
      valid: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }
  }
}

// Function to fetch database schema information
async function fetchDatabaseSchema(): Promise<any> {
  const useMockData = process.env.USE_MOCK_DATA === 'TRUE';
  
  if (useMockData) {
    console.log("Using mock database schema data");
    return { 
      success: true, 
      tables: getFormattedSchemaData().tables,
      source: 'mock'
    };
  }
  
  try {
    console.log("Fetching real database schema");
    const supabase = createClient();
    
    // Query for tables
    const { data: tables, error: tablesError } = await supabase
      .from('pg_tables')
      .select('schemaname,tablename')
      .eq('schemaname', 'public');
      
    if (tablesError) {
      console.error("Error fetching tables:", tablesError);
      throw tablesError;
    }
    
    // Now get columns for each table
    const tablesWithColumns = [];
    
    for (const table of tables || []) {
      try {
        // Just query the table to get its structure
        const { error: columnError } = await supabase
          .from(table.tablename)
          .select('*')
          .limit(0);
          
        // Add table info
        tablesWithColumns.push({
          schema: table.schemaname,
          name: table.tablename,
          hasColumns: !columnError,
          error: columnError ? columnError.message : null
        });
      } catch (err) {
        console.error(`Error fetching columns for ${table.tablename}:`, err);
        tablesWithColumns.push({
          schema: table.schemaname,
          name: table.tablename,
          hasColumns: false,
          error: err instanceof Error ? err.message : 'Unknown error'
        });
      }
    }
    
    return {
      success: true,
      tables: tablesWithColumns,
      count: tablesWithColumns.length,
      timestamp: new Date().toISOString(),
      source: 'database'
    };
  } catch (error) {
    console.error("Error fetching database schema:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    };
  }
}

// Function to fetch all database views
async function fetchDatabaseViews(): Promise<any> {
  const useMockData = process.env.USE_MOCK_DATA === 'TRUE';
  
  if (useMockData) {
    console.log("Using mock database views data");
    return { 
      success: true, 
      views: getFormattedViewsData().views,
      source: 'mock'
    };
  }
  
  try {
    console.log("Fetching real database views");
    const supabase = createClient();
    
    // Query for views
    const { data: views, error: viewsError } = await supabase
      .from('pg_views')
      .select('schemaname,viewname,definition')
      .eq('schemaname', 'public');
      
    if (viewsError) {
      console.error("Error fetching views:", viewsError);
      throw viewsError;
    }
    
    return {
      success: true,
      views: views || [],
      count: views?.length || 0,
      timestamp: new Date().toISOString(),
      source: 'database'
    };
  } catch (error) {
    console.error("Error fetching database views:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    };
  }
}

export async function POST(request: Request) {
  try {
    // Check if the request body is valid
    let body
    try {
      body = await request.json() as QueryRequest
    } catch (error) {
      return NextResponse.json(
        { error: 'Invalid request body format' },
        { status: 400 }
      )
    }

    if (!body || typeof body.query !== 'string') {
      return NextResponse.json(
        { error: 'Query parameter is required and must be a string' },
        { status: 400 }
      )
    }

    // Log query for debugging
    console.log(`Processing query request: "${body.query}"`);
    
    // Validate Supabase connection
    console.log('Supabase environment check:', { 
      hasUrl: !!process.env.NEXT_PUBLIC_SUPABASE_URL, 
      hasKey: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
      urlLength: process.env.NEXT_PUBLIC_SUPABASE_URL?.length || 0,
      keyLength: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length || 0
    })

    // Handle database test command
    if (body.query.toLowerCase().includes('test database') || body.query.toLowerCase().includes('check database')) {
      console.log('Running database connection test...');
      try {
        // Use the new test function
        const testResult = await testSupabaseConnection();
        
        // Also validate required tables
        const tableValidation = await validateRequiredTables();
        
        // Check if exec_sql is available
        const hasExecSql = await checkExecSqlAvailability();
        
        return NextResponse.json({
          type: 'database_test',
          success: testResult.success,
          connection: testResult,
          tables: tableValidation,
          features: {
            execSql: hasExecSql
          },
          environment: {
            hasUrl: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
            hasKey: !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
            node_env: process.env.NODE_ENV || 'unknown'
          },
          message: testResult.success 
            ? `Database connection successful. Response time: ${testResult.responseTime}ms` 
            : `Database connection failed: ${testResult.error}`
        });
      } catch (dbError) {
        console.error('Error during database test:', dbError);
        return NextResponse.json({
          type: 'error',
          success: false,
          message: `Database connection test failed with exception: ${dbError instanceof Error ? dbError.message : 'Unknown error'}`,
          error: dbError instanceof Error ? dbError.message : 'Unknown error',
          stack: dbError instanceof Error ? dbError.stack : null
        }, { status: 500 });
      }
    }

    // Check for OpenAI API key
    console.log('OpenAI API key check:', {
      hasKey: !!process.env.OPENAI_API_KEY,
      keyLength: process.env.OPENAI_API_KEY?.length || 0,
      initialized: openaiInitialized
    });

    // Handle OpenAI connectivity test
    if (body.query.toLowerCase().includes('test openai')) {
      const pingResult = await pingOpenAI();
      return NextResponse.json({
        type: 'openai_test',
        success: pingResult.success,
        message: pingResult.success 
          ? `OpenAI API connectivity test successful: ${pingResult.message}` 
          : `OpenAI API connectivity test failed: ${pingResult.error}`,
        error: pingResult.success ? undefined : pingResult.error
      });
    }

    // If the query is to generate a daily report, process it with AI
    if (body.query.toLowerCase().includes('generate daily report')) {
      // First test connectivity without token usage
      const pingResult = await pingOpenAI();
      if (!pingResult.success) {
        return NextResponse.json({
          type: 'error',
          data: null,
          error: pingResult.error,
          message: `Could not connect to OpenAI: ${pingResult.error}`
        }, { status: 500 });
      }
      
      // In test mode, just return a mock response
      return NextResponse.json({
        type: 'ai_report',
        data: null,
        ai_content: "This is a placeholder for the daily report. OpenAI connection is working, but we're in test mode to avoid token usage.",
        message: 'Mock daily report generated (test mode)',
        openai_status: 'Connected but in test mode'
      });
    }

    const query = body.query.toLowerCase()

    // Test OpenAI without using tokens if query is complex enough
    let aiResponse = null;
    let aiConnectionStatus = null;
    if (query.length > 5 && !query.includes('last 7 days') && !query.includes('high cpa')) {
      const pingResult = await pingOpenAI();
      aiConnectionStatus = pingResult.success ? 'connected' : 'error';
      
      if (pingResult.success) {
        // In test mode, use a placeholder response
        aiResponse = "This is a placeholder AI response. OpenAI connection is working, but we're in test mode to avoid token usage.";
      } else {
        console.warn('OpenAI connectivity test failed:', pingResult.error);
        aiResponse = `AI service is unavailable: ${pingResult.error}`;
      }
    }

    // Handle database schema queries
    if (query.includes('schema') || query.includes('tables') || query.includes('database structure')) {
      console.log('Handling schema query...');
      const schemaResult = await fetchDatabaseSchema();
      
      if (!schemaResult.success) {
        return NextResponse.json({
          type: 'error',
          data: null,
          message: `Error fetching database schema: ${schemaResult.error}`,
          aiResponse: aiResponse,
          openai_status: aiConnectionStatus
        }, { status: 500 });
      }
      
      return NextResponse.json({
        type: 'schema',
        data: schemaResult.tables,
        message: 'Database schema information',
        aiResponse: aiResponse,
        openai_status: aiConnectionStatus,
        source: schemaResult.source
      });
    }
    
    // Handle database views queries
    if (query.includes('views') || query.includes('view')) {
      console.log('Handling views query...');
      const viewsResult = await fetchDatabaseViews();
      
      if (!viewsResult.success) {
        return NextResponse.json({
          type: 'error',
          data: null,
          message: `Error fetching database views: ${viewsResult.error}`,
          aiResponse: aiResponse,
          openai_status: aiConnectionStatus
        }, { status: 500 });
      }
      
      return NextResponse.json({
        type: 'views',
        data: viewsResult.views,
        message: 'Database views information',
        aiResponse: aiResponse,
        openai_status: aiConnectionStatus,
        source: viewsResult.source
      });
    }

    // Create Supabase client for database queries
    const supabase = createClient();

    // Extract business name if query starts with "Hey [business_name]"
    let businessNameMatch = query.match(/^hey\s+([^,\.!?]+)/)
    let businessName = businessNameMatch ? businessNameMatch[1].trim() : null

    // Queries about last 7 days performance
    if (query.includes('last 7 days') || query.includes('last seven days') || query.includes('weekly') || query.includes('week performance')) {
      console.log('Handling last 7 days performance query...');
      
      // Validate required tables
      const tableValidation = await validateRequiredTables()
      if (!tableValidation.valid) {
        console.error('Missing required tables:', tableValidation.missingTables)
        return NextResponse.json(
          { 
            error: 'Database schema is not properly set up',
            details: `Missing tables: ${JSON.stringify(tableValidation.missingTables)}`,
            validation: tableValidation,
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus
          },
          { status: 500 }
        )
      }
      
      try {
        let queryBuilder = supabase
          .from('last_7_day_totals')
          .select('*')
          
        // Filter by business name if provided
        if (businessName) {
          queryBuilder = queryBuilder.ilike('business_id', `%${businessName}%`)
        }
        
        const { data, error } = await queryBuilder.limit(20)

        if (error) {
          console.error('Error querying last_7_day_totals:', error)
          return NextResponse.json(
            { 
              error: 'Error retrieving performance data',
              details: error.message,
              code: error.code,
              aiResponse: aiResponse,
              openai_status: aiConnectionStatus
            },
            { status: 500 }
          )
        }

        if (!data || data.length === 0) {
          return NextResponse.json({
            type: 'empty',
            data: [],
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus,
            message: businessName 
              ? `No performance data found for ${businessName} in the last 7 days`
              : 'No performance data found for the last 7 days'
          })
        }

        const message = businessName 
          ? `Here's the last 7 days performance for ${businessName}`
          : 'Here\'s the last 7 days performance across all businesses'

        return NextResponse.json({
          type: 'performance',
          data,
          aiResponse: aiResponse,
          openai_status: aiConnectionStatus,
          message
        })
      } catch (queryError) {
        console.error('Exception querying last_7_day_totals:', queryError);
        return NextResponse.json(
          { 
            error: 'Exception retrieving performance data',
            details: queryError instanceof Error ? queryError.message : 'Unknown error',
            stack: queryError instanceof Error ? queryError.stack : null,
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus
          },
          { status: 500 }
        )
      }
    }

    // High CPA alerts
    if (query.includes('high cpa') || query.includes('cpa alert') || query.includes('expensive conversion')) {
      console.log('Handling high CPA alerts query...');
      
      // Validate required tables
      const tableValidation = await validateRequiredTables()
      if (!tableValidation.valid) {
        console.error('Missing required tables:', tableValidation.missingTables)
        return NextResponse.json(
          { 
            error: 'Database schema is not properly set up',
            details: `Missing tables: ${JSON.stringify(tableValidation.missingTables)}`,
            validation: tableValidation,
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus
          },
          { status: 500 }
        )
      }
      
      try {
        let queryBuilder = supabase
          .from('alert_high_cpa')
          .select('*')
        
        // Filter by business name if provided
        if (businessName) {
          queryBuilder = queryBuilder.ilike('business_id', `%${businessName}%`)
        }
        
        const { data, error } = await queryBuilder.limit(20)

        if (error) {
          console.error('Error querying alert_high_cpa:', error)
          return NextResponse.json(
            { 
              error: 'Error retrieving CPA alerts',
              details: error.message,
              code: error.code,
              aiResponse: aiResponse,
              openai_status: aiConnectionStatus
            },
            { status: 500 }
          )
        }

        if (!data || data.length === 0) {
          return NextResponse.json({
            type: 'empty',
            data: [],
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus,
            message: businessName 
              ? `No high CPA alerts found for ${businessName}`
              : 'No high CPA alerts found across any businesses'
          })
        }

        const message = businessName 
          ? `Here are the high CPA alerts for ${businessName}`
          : 'Here are the high CPA alerts across all businesses'

        return NextResponse.json({
          type: 'alert',
          data,
          aiResponse: aiResponse,
          openai_status: aiConnectionStatus,
          message
        })
      } catch (queryError) {
        console.error('Exception querying alert_high_cpa:', queryError);
        return NextResponse.json(
          { 
            error: 'Exception retrieving CPA alerts',
            details: queryError instanceof Error ? queryError.message : 'Unknown error',
            stack: queryError instanceof Error ? queryError.stack : null,
            aiResponse: aiResponse,
            openai_status: aiConnectionStatus
          },
          { status: 500 }
        )
      }
    }

    // If we have an AI response but no structured data matches
    if (aiResponse) {
      return NextResponse.json({
        type: 'ai_only',
        data: null,
        aiResponse: aiResponse,
        openai_status: aiConnectionStatus,
        message: 'AI-generated response (test mode)'
      });
    }

    // Default response for unrecognized queries
    return NextResponse.json({
      type: 'help',
      data: null,
      aiResponse: null,
      openai_status: openaiInitialized ? 'available' : 'not_configured',
      message: 'Try asking about:\n- "Last 7 days performance"\n- "High CPA alerts"\n- "Hey [business name], how was last week\'s performance?"\n- "Hey [business name], show me high CPA alerts"\n- "Test OpenAI" to check API connectivity\n- "Show database schema" to see all tables\n- "Show views" to see all database views\n- "Test database" to check database connectivity'
    })

  } catch (error) {
    console.error('Error processing query:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred'
    const stack = error instanceof Error ? error.stack : undefined
    
    // Log more details for debugging
    console.error({
      message: errorMessage,
      stack,
      timestamp: new Date().toISOString()
    })
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        message: errorMessage,
        stack: stack,
        requestId: Date.now().toString(), // For tracking errors
        openai_status: openaiInitialized ? 'available' : 'not_configured'
      },
      { status: 500 }
    )
  }
} 