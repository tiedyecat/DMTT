import { NextResponse } from 'next/server';
import { MetaAPI } from '@/lib/MetaAPI';

interface MetaResponse<T> {
  data: T[];
  paging?: {
    cursors: {
      before: string;
      after: string;
    };
    next?: string;
  };
}

export async function GET(request: Request) {
  try {
    if (!process.env.META_ACCESS_TOKEN) {
      return NextResponse.json({ error: 'META_ACCESS_TOKEN not configured' }, { status: 500 });
    }

    const api = new MetaAPI(process.env.META_ACCESS_TOKEN);
    
    // First test: Get account info
    const accounts = await api.getAccounts();
    
    // Second test: Get last 7 days of data
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const today = new Date();
    
    const recentData = await api.getCustomInsights(
      'act_797120043955249', // Physiq Fitness account
      sevenDaysAgo.toISOString().split('T')[0],
      today.toISOString().split('T')[0],
      ['spend', 'impressions', 'clicks', 'conversions']
    );

    return NextResponse.json({
      success: true,
      accounts: accounts.data,
      recentData: recentData.data,
      meta: {
        accountCount: accounts.data.length,
        dataPoints: recentData.data?.length || 0
      }
    });

  } catch (error: any) {
    console.error('Meta API Test Error:', error.response?.data || error.message);
    return NextResponse.json({
      success: false,
      error: error.message,
      details: error.response?.data
    }, { status: 500 });
  }
} 