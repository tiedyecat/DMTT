import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase'

interface AnalyzeRequest {
  query: string
  data?: any
}

export async function POST(request: Request) {
  try {
    const { query, data } = await request.json() as AnalyzeRequest
    const openaiApiKey = process.env.OPENAI_API_KEY

    if (!openaiApiKey) {
      return NextResponse.json(
        { error: 'OpenAI API key is not configured' },
        { status: 500 }
      )
    }

    // Fetch data from Supabase if not provided
    let analysisData = data
    if (!analysisData) {
      const supabase = createClient()
      // Determine which data to fetch based on query keywords
      if (query.toLowerCase().includes('facebook') || query.toLowerCase().includes('ads')) {
        const { data: adsData } = await supabase
          .from('meta_ads_monitoring')
          .select('*')
          .order('date', { ascending: false })
          .limit(10)
        analysisData = adsData
      } else if (query.toLowerCase().includes('demographics')) {
        const { data: demographicsData } = await supabase
          .from('meta_ads_demographics')
          .select('*')
          .order('date', { ascending: false })
          .limit(10)
        analysisData = demographicsData
      }
      // Add more data sources as needed
    }

    // Call OpenAI API to analyze the data
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openaiApiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful analytics assistant that provides insights about marketing data. Provide concise, clear analysis with key observations and actionable recommendations.'
          },
          {
            role: 'user',
            content: `Please analyze this marketing data and provide insights in response to this query: "${query}". Data: ${JSON.stringify(analysisData)}`
          }
        ],
        temperature: 0.7,
        max_tokens: 800
      })
    })

    if (!openaiResponse.ok) {
      const errorText = await openaiResponse.text();
      console.error('OpenAI API error:', errorText);
      return NextResponse.json(
        { error: `OpenAI API error: ${openaiResponse.status}` },
        { status: openaiResponse.status }
      );
    }

    const aiResult = await openaiResponse.json();
    
    return NextResponse.json({
      type: 'ai_analysis',
      data: analysisData,
      analysis: aiResult.choices[0].message.content,
      message: 'AI analysis completed'
    })

  } catch (error) {
    console.error('Error processing request:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
} 