import { createClient } from '@/lib/supabase';
import { NextResponse } from 'next/server';
import { AlertHighCPA } from '@/types/database';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const accountId = searchParams.get('accountId');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const flagged = searchParams.get('flagged');

    const supabase = createClient();
    
    let query = supabase
      .from('alert_high_cpa')
      .select('*', { count: 'exact' });

    // Apply filters
    if (accountId) {
      query = query.eq('account_id', accountId);
    }
    if (startDate) {
      query = query.gte('date', startDate);
    }
    if (endDate) {
      query = query.lte('date', endDate);
    }
    if (flagged !== null) {
      query = query.eq('flagged', flagged === 'true');
    }

    // Apply pagination
    const from = (page - 1) * limit;
    const to = from + limit - 1;
    
    const { data, error, count } = await query
      .order('date', { ascending: false })
      .range(from, to);

    if (error) {
      console.error('Error fetching high CPA alerts:', error);
      return NextResponse.json(
        { error: 'Failed to fetch alerts' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      alerts: data as AlertHighCPA[],
      total: count,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit)
    });
  } catch (err) {
    console.error('Unexpected error while fetching high CPA alerts:', err);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 