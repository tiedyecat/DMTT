import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { MetaDataBackfill } from '@/lib/MetaDataBackfill';

interface BackfillProgress {
  accountId: string;
  status: 'running' | 'completed' | 'error';
  currentRange?: string;
  error?: string;
  completedRanges: string[];
  startTime: string;
  endTime?: string;
}

const progressMap = new Map<string, BackfillProgress>();

export async function GET(request: NextRequest) {
  console.log('Received backfill request');
  
  // Validate environment variables
  const envCheck = validateEnvironment();
  if (!envCheck.valid) {
    console.error('Environment validation failed:', envCheck.error);
    return NextResponse.json({ error: envCheck.error }, { status: 400 });
  }

  const { searchParams } = new URL(request.url);
  const accountId = searchParams.get('account_id');
  const checkProgress = searchParams.get('check_progress') === 'true';
  const clearProgress = searchParams.get('clear_progress') === 'true';

  if (!accountId) {
    console.error('Missing account_id parameter');
    return NextResponse.json({ error: 'Missing account_id parameter' }, { status: 400 });
  }

  // Handle progress check
  if (checkProgress) {
    const progress = progressMap.get(accountId);
    return NextResponse.json({ progress: progress || null });
  }

  // Handle progress clear
  if (clearProgress) {
    progressMap.delete(accountId);
    return NextResponse.json({ message: 'Progress cleared' });
  }

  // Check if backfill is already running
  const existingProgress = progressMap.get(accountId);
  if (existingProgress && existingProgress.status === 'running') {
    console.log(`Backfill already running for account ${accountId}`);
    return NextResponse.json({ 
      error: 'Backfill already in progress',
      progress: existingProgress 
    });
  }

  try {
    // Initialize progress tracking
    const progress: BackfillProgress = {
      accountId,
      status: 'running',
      completedRanges: [],
      startTime: new Date().toISOString()
    };
    progressMap.set(accountId, progress);

    // Initialize backfill service
    console.log('Initializing backfill service...');
    const backfill = new MetaDataBackfill(
      process.env.META_ACCESS_TOKEN!,
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    );

    // Start backfill process
    console.log(`Starting backfill for account ${accountId}`);
    const result = await backfill.backfillData(accountId, (range, data, error) => {
      if (error) {
        console.error(`Error in range ${range.label}:`, error);
        progress.error = error;
      } else {
        console.log(`Completed range ${range.label}`);
        progress.completedRanges.push(range.label);
      }
      progress.currentRange = range.label;
      progressMap.set(accountId, progress);
    });

    // Update final progress
    progress.status = result.errors.length === 0 ? 'completed' : 'error';
    progress.endTime = new Date().toISOString();
    progressMap.set(accountId, progress);

    return NextResponse.json({
      success: result.errors.length === 0,
      errors: result.errors,
      data: result.data,
      progress
    });

  } catch (error: any) {
    console.error('Backfill error:', error);
    
    // Update progress with error
    const progress = progressMap.get(accountId);
    if (progress) {
      progress.status = 'error';
      progress.error = error.message || 'Unknown error occurred';
      progress.endTime = new Date().toISOString();
      progressMap.set(accountId, progress);
    }

    return NextResponse.json({
      error: error.message || 'Unknown error occurred',
      details: error.response?.data || error,
      progress
    }, { status: 500 });
  }
}

function validateEnvironment() {
  console.log('Validating environment variables...');
  const required = ['META_ACCESS_TOKEN', 'NEXT_PUBLIC_SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'];
  const missing = required.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    return {
      valid: false,
      error: `Missing required environment variables: ${missing.join(', ')}`
    };
  }

  // Validate token format/length
  if (process.env.META_ACCESS_TOKEN!.length < 50) {
    return {
      valid: false,
      error: 'Invalid META_ACCESS_TOKEN format'
    };
  }

  // Validate Supabase URL format
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL!.startsWith('https://')) {
    return {
      valid: false,
      error: 'Invalid NEXT_PUBLIC_SUPABASE_URL format'
    };
  }

  return { valid: true };
} 