import { createServiceClient } from '@/lib/supabase'
import OpenAI from 'openai'
import { NextResponse } from 'next/server'

export const runtime = 'edge'

interface AIRequest {
  query: string
  context?: {
    businessId?: string
    dateRange?: string
    dataType?: string
  }
  data?: any
}

interface PerformanceMetrics {
  totalSpend: number
  totalImpressions: number
  totalClicks: number
  totalConversions: number
  avgCPA: number
  avgCTR: number
  avgCPC: number
}

// Initialize OpenAI client
const openaiApiKey = process.env.OPENAI_API_KEY;
if (!openaiApiKey) {
  console.error('Missing OPENAI_API_KEY environment variable');
  throw new Error('OpenAI API key not configured');
}

const openai = new OpenAI({
  apiKey: openaiApiKey,
});

// Initialize Supabase client
const supabase = createServiceClient()

function calculateMetrics(data: any[]): PerformanceMetrics {
  const totals = data.reduce((acc, row) => {
    return {
      spend: acc.spend + (parseFloat(row.spend) || 0),
      impressions: acc.impressions + (parseInt(row.impressions) || 0),
      clicks: acc.clicks + (parseInt(row.clicks) || 0),
      conversions: acc.conversions + (parseInt(row.conversions) || 0)
    }
  }, { spend: 0, impressions: 0, clicks: 0, conversions: 0 })

  return {
    totalSpend: totals.spend,
    totalImpressions: totals.impressions,
    totalClicks: totals.clicks,
    totalConversions: totals.conversions,
    avgCPA: totals.conversions > 0 ? totals.spend / totals.conversions : 0,
    avgCTR: totals.impressions > 0 ? (totals.clicks / totals.impressions) * 100 : 0,
    avgCPC: totals.clicks > 0 ? totals.spend / totals.clicks : 0
  }
}

function getDateFromRange(range: string): Date {
  const now = new Date();
  switch (range) {
    case 'last_7_days':
      return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    case 'last_30_days':
      return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    case 'last_90_days':
      return new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    default:
      return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); // Default to last 7 days
  }
}

async function getRelevantData(businessId?: string, dateRange?: string): Promise<{ data: any[], businessName?: string }> {
  const supabase = createServiceClient()
  
  try {
    // Fetch business name if ID provided
    let businessName
    if (businessId) {
      const { data: business, error: businessError } = await supabase
        .from('businesses')
        .select('name')
        .eq('id', businessId)
        .single()

      if (businessError) {
        console.error('Error fetching business:', businessError)
      } else {
        businessName = business?.name
      }
    }

    // Fetch performance data
    const { data, error } = await supabase
      .from('performance_metrics')
      .select('*')
      .order('date', { ascending: false })

    if (error) {
      console.error('Database error:', error)
      throw new Error(`Failed to fetch data: ${error.message}`)
    }

    if (!data || data.length === 0) {
      throw new Error('No data found for the specified criteria')
    }

    // Filter by date range if provided
    let filteredData = data
    if (dateRange) {
      const startDate = getDateFromRange(dateRange)
      filteredData = data.filter(row => new Date(row.date) >= startDate)
    }

    if (businessId) {
      filteredData = filteredData.filter(row => row.business_id === businessId)
    }

    return { data: filteredData, businessName }
  } catch (error) {
    console.error('Error in getRelevantData:', error)
    throw error
  }
}

export async function POST(request: Request) {
  try {
    const { query, context, data: providedData } = await request.json() as AIRequest

    // Get relevant data from Supabase if not provided
    const data = providedData || await getRelevantData(context?.businessId, context?.dateRange)

    // Prepare system message based on context and data
    let systemMessage = 'You are a helpful marketing analytics assistant that provides insights about business performance data. '
    systemMessage += 'Format your responses with clear sections using markdown headings. '
    systemMessage += 'Always include a "Key Metrics" section and an "Insights & Recommendations" section. '
    
    if (data?.businessName) {
      systemMessage += `You are currently analyzing data for ${data.businessName}. `
    }
    if (context?.dateRange) {
      systemMessage += `The data is from ${context.dateRange}. `
    }
    if (data?.metrics) {
      systemMessage += `\n\nHere are the key metrics for reference:\n`
      systemMessage += `- Total Spend: $${data.metrics.totalSpend.toFixed(2)}\n`
      systemMessage += `- Total Impressions: ${data.metrics.totalImpressions.toLocaleString()}\n`
      systemMessage += `- Total Clicks: ${data.metrics.totalClicks.toLocaleString()}\n`
      systemMessage += `- Total Conversions: ${data.metrics.totalConversions.toLocaleString()}\n`
      systemMessage += `- Average CPA: $${data.metrics.avgCPA.toFixed(2)}\n`
      systemMessage += `- Average CTR: ${data.metrics.avgCTR.toFixed(2)}%\n`
      systemMessage += `- Average CPC: $${data.metrics.avgCPC.toFixed(2)}\n`
    }

    // Call OpenAI API
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { 
          role: "system", 
          content: systemMessage
        },
        { 
          role: "user", 
          content: `Please analyze this data and answer this query: "${query}". Focus on trends, anomalies, and actionable insights. Here's the raw data for additional context: ${JSON.stringify(data?.data)}`
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    })

    const aiResponse = completion.choices[0]?.message?.content || 'No response generated'

    return NextResponse.json({
      success: true,
      query,
      context: {
        ...context,
        businessName: data?.businessName
      },
      metrics: data?.metrics,
      dateRange: data?.dateRange,
      analysis: aiResponse
    })

  } catch (error) {
    console.error('Error in AI edge function:', error)
    
    let errorDetails = {
      query: '',
      type: 'unknown',
      message: 'An unknown error occurred'
    }

    try {
      const body = await request.json() as AIRequest
      errorDetails.query = body.query

      if (error instanceof Error) {
        errorDetails.message = error.message
        if (error.message.includes('Database error')) {
          errorDetails.type = 'database'
        } else if (error.message.includes('No data found')) {
          errorDetails.type = 'no_data'
        } else if (error.message.includes('OpenAI')) {
          errorDetails.type = 'ai'
        }
      }
    } catch {
      // If we can't parse the request body, use default error details
    }

    return NextResponse.json({
      success: false,
      error: errorDetails.message,
      errorType: errorDetails.type,
      query: errorDetails.query,
      context: null,
      metrics: null,
      analysis: null
    }, { status: 500 })
  }
} 