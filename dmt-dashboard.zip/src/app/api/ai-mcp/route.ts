import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import OpenAI from 'openai'

export const runtime = 'edge'

interface AIRequest {
  query: string
  context?: {
    businessId?: string
    dateRange?: string
    dataType?: string
  }
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: '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'
})

// Initialize Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
)

async function getSchemaInfo() {
  try {
    console.log('Fetching schema information...')
    
    // Try to query known tables directly
    const knownTables = [
      'meta_accounts',
      'last_7_day_totals',
      'ai_flags_log',
      'ai_summaries',
      'alert_high_cpa'
    ]

    const tableInfo = []
    
    for (const tableName of knownTables) {
      try {
        const { data, error } = await supabase
          .from(tableName)
          .select('*')
          .limit(1)

        if (!error && data) {
          const columns = Object.keys(data[0] || {}).map(col => ({
            name: col,
            type: typeof data[0][col],
            sample: data[0][col]
          }))

          tableInfo.push({
            name: tableName,
            type: 'table',
            columns
          })
        }
      } catch (e) {
        console.log(`Table ${tableName} not found or not accessible`)
      }
    }

    return {
      tables: tableInfo,
      views: []
    }
  } catch (error) {
    console.error('Error in getSchemaInfo:', error)
    throw error
  }
}

async function getBusinessData(businessId?: string, dateRange?: string) {
  try {
    let query = supabase
      .from('last_7_day_totals')
      .select('*')

    if (businessId) {
      query = query.eq('business_id', businessId)
    }

    if (dateRange === 'last_30_days') {
      query = query.gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
    } else if (dateRange === 'last_90_days') {
      query = query.gte('created_at', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString())
    }

    const { data, error } = await query.limit(100)
    if (error) throw error

    return data
  } catch (error) {
    console.error('Error fetching business data:', error)
    return null
  }
}

export async function POST(request: Request) {
  try {
    const { query, context } = await request.json() as AIRequest

    console.log('Processing query:', query)

    // Get enhanced schema information
    const schemaInfo = await getSchemaInfo()
    console.log('Schema info retrieved:', schemaInfo)
    
    // Get business data
    const businessData = await getBusinessData(context?.businessId, context?.dateRange)
    console.log('Business data retrieved:', businessData ? 'yes' : 'no')

    // Prepare system message with enhanced context
    let systemMessage = 'You are a marketing analytics assistant with deep knowledge of database structures. '
    
    if (schemaInfo) {
      systemMessage += `\n\nDatabase Schema:\n${JSON.stringify(schemaInfo, null, 2)}\n\n`
    }

    if (businessData) {
      systemMessage += `\n\nBusiness Data Sample:\n${JSON.stringify(businessData.slice(0, 5), null, 2)}\n\n`
    }

    systemMessage += 'Analyze the data and provide insights focusing on:\n'
    systemMessage += '1. Performance trends\n'
    systemMessage += '2. Anomalies or areas of concern\n'
    systemMessage += '3. Actionable recommendations\n'
    systemMessage += '4. Relevant database structure insights\n'

    console.log('Calling OpenAI...')

    // Call OpenAI with enhanced context
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: systemMessage },
        { role: "user", content: query }
      ],
      temperature: 0.7,
      max_tokens: 1000
    })

    console.log('OpenAI response received')

    return NextResponse.json({
      success: true,
      query,
      context,
      schema: schemaInfo,
      data: businessData,
      analysis: completion.choices[0]?.message?.content || 'No analysis generated'
    })

  } catch (error) {
    console.error('Error in MCP endpoint:', error)
    
    let errorType = 'unknown'
    let errorMessage = 'An unknown error occurred'

    if (error instanceof Error) {
      errorMessage = error.message
      if (error.message.includes('schema')) {
        errorType = 'schema'
      } else if (error.message.includes('database')) {
        errorType = 'database'
      } else if (error.message.includes('OpenAI')) {
        errorType = 'ai'
      }
    }

    return NextResponse.json({
      success: false,
      error: errorMessage,
      errorType,
      query: (await request.json() as AIRequest).query
    }, { status: 500 })
  }
} 