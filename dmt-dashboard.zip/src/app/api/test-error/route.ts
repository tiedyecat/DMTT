import { NextResponse } from 'next/server';
import { AppError } from '@/lib/errors';
import { notifyError } from '@/lib/errorNotifications';

// Handle OPTIONS requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

// Handle GET requests to show API status
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'API is running. Use POST to test error notifications.'
  });
}

export async function POST() {
  try {
    // Create a test error
    const error = new AppError({
      message: 'Test error notification',
      statusCode: 500,
      code: 'TEST_ERROR',
      context: {
        testId: 'test-123',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV,
        testData: {
          sample: 'data',
          value: 42
        }
      }
    });

    // Notify about the error
    const notificationSent = await notifyError(error);
    
    if (!notificationSent) {
      throw new AppError({
        message: 'Failed to send notification',
        statusCode: 500,
        code: 'NOTIFICATION_FAILED'
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Test error notification sent',
      error: {
        message: error.message,
        code: error.code,
        statusCode: error.statusCode,
        context: error.context
      }
    });
  } catch (error) {
    console.error('Error in test-error API route:', error);
    
    if (error instanceof AppError) {
      return NextResponse.json({
        success: false,
        message: error.message,
        error: {
          code: error.code,
          statusCode: error.statusCode,
          context: error.context
        }
      }, { status: error.statusCode });
    }

    return NextResponse.json({
      success: false,
      message: 'An unexpected error occurred',
      error: {
        message: error instanceof Error ? error.message : 'Unknown error',
        code: 'INTERNAL_SERVER_ERROR',
        statusCode: 500
      }
    }, { status: 500 });
  }
} 