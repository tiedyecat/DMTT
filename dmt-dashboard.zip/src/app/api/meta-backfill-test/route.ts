import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { MetaDataBackfill } from '@/lib/MetaDataBackfill';

export async function GET(request: Request) {
  try {
    if (!process.env.META_ACCESS_TOKEN) {
      return NextResponse.json({ error: 'META_ACCESS_TOKEN not configured' }, { status: 500 });
    }
    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_KEY) {
      return NextResponse.json({ error: 'Supabase configuration missing' }, { status: 500 });
    }

    const supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_KEY
    );

    // Test parameters
    const { searchParams } = new URL(request.url);
    const accountId = searchParams.get('account_id') || 'act_797120043955249';
    const mode = searchParams.get('mode') || 'verify';

    if (mode === 'clear') {
      // Clear existing test data
      const { error } = await supabase
        .from('meta_historical_data')
        .delete()
        .eq('account_id', accountId);

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      return NextResponse.json({ message: 'Test data cleared' });
    }

    if (mode === 'verify') {
      // Verify stored data
      const { data: storedData, error } = await supabase
        .from('meta_historical_data')
        .select('*')
        .eq('account_id', accountId)
        .order('updated_at', { ascending: false });

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 500 });
      }

      // Group data by range
      const summary = storedData.reduce((acc: any, row) => {
        acc[row.range_label] = {
          updated_at: row.updated_at,
          record_count: row.data?.data?.length || 0,
          has_data: !!row.data
        };
        return acc;
      }, {});

      return NextResponse.json({
        message: 'Data verification complete',
        account_id: accountId,
        ranges_found: Object.keys(summary).length,
        summary
      });
    }

    // Start a test backfill
    const backfiller = new MetaDataBackfill(
      process.env.META_ACCESS_TOKEN,
      process.env.SUPABASE_URL,
      process.env.SUPABASE_KEY
    );

    const result = await backfiller.backfillData(
      accountId,
      (range, data, error) => {
        console.log(`Progress - Range: ${range.label}, Records: ${data?.data?.length || 0}${error ? `, Error: ${error}` : ''}`);
      }
    );

    return NextResponse.json({
      message: 'Test backfill complete',
      success: result.success,
      error_count: result.errors.length,
      ranges_processed: Object.keys(result.data).length,
      all_time_stats: result.allTimeStats,
      verify_url: `${request.url.split('?')[0]}?mode=verify&account_id=${accountId}`,
      clear_url: `${request.url.split('?')[0]}?mode=clear&account_id=${accountId}`
    });

  } catch (error: any) {
    console.error('Meta Backfill Test Error:', error);
    return NextResponse.json({
      success: false,
      error: error.message
    }, { status: 500 });
  }
} 