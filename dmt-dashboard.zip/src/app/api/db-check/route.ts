import { createClient } from '@/lib/supabase'
import { NextResponse } from 'next/server'
import { PostgrestError } from '@supabase/supabase-js'

export const dynamic = 'force-dynamic' // Ensure we always check latest data

// Check if Supabase environment is configured correctly
function validateSupabaseEnv() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  
  const check = { 
    hasUrl: !!url, 
    hasKey: !!key,
    urlLength: url?.length || 0,
    keyLength: key?.length || 0 
  }
  
  console.log('Supabase environment check:', check)
  
  return {
    isValid: check.hasUrl && check.hasKey && check.urlLength > 0 && check.keyLength > 0,
    details: check
  }
}

export async function GET(request: Request) {
  try {
    // Validate environment before attempting connection
    const envCheck = validateSupabaseEnv()
    if (!envCheck.isValid) {
      return NextResponse.json(
        { 
          error: 'Supabase environment not properly configured',
          details: envCheck.details
        },
        { status: 500 }
      )
    }
    
    const supabase = createClient()
    
    // Test basic connection first
    try {
      const { error: connectionError } = await supabase.from('_dummy_query').select('*').limit(1).throwOnError()
      
      // If we get a "relation does not exist" error, that actually means our connection is working
      // but the table doesn't exist, which is expected for this test
      if (connectionError && 
          typeof connectionError === 'object' && 
          'message' in connectionError && 
          typeof connectionError.message === 'string' &&
          !connectionError.message.includes('relation') && 
          !connectionError.message.includes('does not exist')) {
        return NextResponse.json(
          { 
            error: 'Failed to connect to Supabase',
            details: connectionError
          },
          { status: 500 }
        )
      }
    } catch (connErr) {
      // If it's not a relation error, it's a real connection problem
      if (connErr instanceof Error && 
          !connErr.message.includes('relation') && 
          !connErr.message.includes('does not exist')) {
        return NextResponse.json(
          { 
            error: 'Failed to connect to Supabase',
            details: connErr instanceof Error ? connErr.message : String(connErr)
          },
          { status: 500 }
        )
      }
    }
    
    const requiredTables = [
      'meta_ads_monitoring',
      'last_7_day_totals',
      'alert_high_cpa'
    ]
    
    const optionalTables = [  
      'meta_ads_demographics',
      'ai_summaries',
      'flag_alert_log',
      'ai_flags_log',
      'gpt_output_log',
      'ai_summary_input_ready'
    ]
    
    const allTables = [...requiredTables, ...optionalTables]
    
    // Query each specified table for row count
    const tableCheckPromises = allTables.map(async (tableName) => {
      try {
        // Get count
        const countResult = await supabase
          .from(tableName)
          .select('*', { count: 'exact', head: true })
        
        // Get first row to check schema
        const sampleResult = await supabase
          .from(tableName)
          .select('*')
          .limit(1)
        
        // Check if there's an error and extract proper error message
        const errorMessage = countResult.error instanceof Error ? 
          countResult.error.message : 
          countResult.error ? 
            (countResult.error as PostgrestError).message || String(countResult.error) : 
            null
            
        const errorCode = countResult.error && 
          typeof countResult.error === 'object' && 
          'code' in countResult.error ? 
            countResult.error.code as string : 
            null
        
        return {
          table: tableName,
          exists: !countResult.error || 
            (errorCode !== '42P01' && // 42P01 is PostgreSQL code for "relation does not exist"
             (errorMessage ? !errorMessage.includes('does not exist') : true)),
          count: countResult.error ? null : countResult.count,
          error: errorMessage,
          has_data: !countResult.error && typeof countResult.count === 'number' && countResult.count > 0,
          schema: sampleResult.data && sampleResult.data.length > 0 ? Object.keys(sampleResult.data[0]) : [],
          required: requiredTables.includes(tableName)
        }
      } catch (err) {
        return {
          table: tableName,
          exists: false,
          count: null,
          error: err instanceof Error ? err.message : String(err),
          has_data: false,
          schema: [],
          required: requiredTables.includes(tableName)
        }
      }
    })
    
    const tableData = await Promise.all(tableCheckPromises)
    
    // Check for missing required tables
    const missingRequiredTables = tableData
      .filter(t => t.required && !t.exists)
      .map(t => t.table)
    
    // Generate report
    const emptyTables = tableData.filter(t => t.exists && t.has_data === false).map(t => t.table)
    const tablesWithData = tableData.filter(t => t.has_data === true)
    const nonExistentTables = tableData.filter(t => !t.exists).map(t => t.table)
    
    // System health status
    const isHealthy = missingRequiredTables.length === 0
    
    return NextResponse.json({
      status: isHealthy ? 'healthy' : 'unhealthy',
      missing_required_tables: missingRequiredTables,
      env_check: envCheck.details,
      summary: {
        total_tables_checked: allTables.length,
        tables_exist: tableData.filter(t => t.exists).length,
        non_existent_tables: nonExistentTables.length,
        empty_tables: emptyTables.length,
        tables_with_data: tablesWithData.length
      },
      empty_tables: emptyTables,
      non_existent_tables: nonExistentTables,
      tables_with_data: tablesWithData.map(t => ({ 
        table: t.table, 
        count: t.count, 
        schema: t.schema
      })),
      details: tableData,
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('Database check error:', error)
    
    // Log detailed error for debugging
    const errorDetails = {
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined,
      timestamp: new Date().toISOString()
    }
    console.error('Error details:', errorDetails)
    
    return NextResponse.json(
      { 
        error: 'Database check failed',
        message: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
} 