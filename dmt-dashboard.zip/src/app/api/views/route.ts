import { NextResponse } from 'next/server';
import { getFormattedViewsData } from '@/lib/mockData';

export async function GET() {
  try {
    console.log('Using mock data for views endpoint');
    
    // Get mock data for views
    const viewsData = getFormattedViewsData();
    
    return NextResponse.json({
      views: viewsData.views,
      timestamp: new Date().toISOString(),
      source: 'Mock Data'
    });
  } catch (error) {
    console.error('Error in views endpoint:', error);
    return NextResponse.json(
      { error: 'Error fetching views' },
      { status: 500 }
    );
  }
} 