import DashboardHeader from '@/components/DashboardHeader';
import QueryBox from '@/components/dashboard/QueryBox';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <DashboardHeader />
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium mb-4">Welcome to the Dashboard</h2>
          <p className="text-gray-600">This is where we&apos;ll add our dashboard components.</p>
          <QueryBox />
        </div>
      </main>
    </div>
  );
}
