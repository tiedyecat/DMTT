import HighCPATable from '@/components/alerts/HighCPATable';

export default function HighCPAPage() {
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">High CPA Alerts</h1>
        <div className="mt-6">
          <HighCPATable />
        </div>
      </div>
    </div>
  );
} 