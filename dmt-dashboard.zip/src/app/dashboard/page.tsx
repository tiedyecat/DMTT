import { Suspense } from 'react';
import SummaryMetrics from '@/components/dashboard/SummaryMetrics';
import AlertOverview from '@/components/dashboard/AlertOverview';
import PerformanceTrends from '@/components/dashboard/PerformanceTrends';
import AIQueryBox from '@/components/dashboard/AIQueryBox';

export default function DashboardPage() {
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        
        {/* AI Query Box */}
        <div className="mt-6">
          <div className="bg-white shadow-sm rounded-lg">
            <AIQueryBox />
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Summary Metrics */}
          <div className="bg-white shadow-sm rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Summary Metrics</h2>
            <Suspense fallback={<div>Loading metrics...</div>}>
              <SummaryMetrics />
            </Suspense>
          </div>

          {/* Alert Overview */}
          <div className="bg-white shadow-sm rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Alert Overview</h2>
            <Suspense fallback={<div>Loading alerts...</div>}>
              <AlertOverview />
            </Suspense>
          </div>
        </div>

        {/* Performance Trends */}
        <div className="mt-6">
          <div className="bg-white shadow-sm rounded-lg p-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Performance Trends</h2>
            <Suspense fallback={<div>Loading trends...</div>}>
              <PerformanceTrends />
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  );
} 