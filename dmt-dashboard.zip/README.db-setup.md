# Database Connection Setup

This document explains how to set up and test your database connection for the DMT Dashboard.

## Setting up Environment Variables

1. In the `dmt-dashboard` directory, you'll find a `.env.local` file with placeholders
2. Replace the placeholder values with your actual Supabase credentials:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-from-supabase
```

3. If using OpenAI features, add your API key:

```
OPENAI_API_KEY=your-openai-api-key
```

4. By default, the app uses mock data instead of real database connections. To use real data:

```
USE_MOCK_DATA=FALSE
```

## Testing Database Connection

After setting up your environment variables, you can test the database connection:

1. Start the development server:
   ```
   npm run dev
   ```

2. Open your browser to `http://localhost:3000`

3. Send the query "test database" to the API using the Dashboard interface

4. The response will show:
   - Connection status (success/failure)
   - Tables validation results
   - Available SQL features
   - Error details (if any)

## Troubleshooting

If you encounter database connection issues:

1. Verify your Supabase URL and key in `.env.local`
2. Check if the Supabase project is active and available
3. Confirm you have the required tables in your database
4. Review logs for detailed error messages

## Required Tables

The application expects these tables to exist:
- `last_7_day_totals`
- `alert_high_cpa`

To test while developing without real tables, keep `USE_MOCK_DATA=TRUE`.
