import { createClient } from '@supabase/supabase-js'
import dotenv from 'dotenv'
import { randomUUID } from 'crypto'

// Load environment variables
dotenv.config()

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing Supabase credentials. Please check your .env file.')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

// Sample business names
const businesses = [
  'Fitness Fanatics',
  'Tech Innovators',
  'Culinary Delights',
  'Fashion Forward',
  'Home Essentials',
  'Travel Adventures',
  'Beauty Basics',
  'Health Harmony',
  'Digital Dreams',
  'Eco Essentials'
]

// Sample campaign names
const campaigns = [
  'Summer Sale',
  'New Product Launch',
  'Holiday Special',
  'Brand Awareness',
  'Customer Retention',
  'Lead Generation',
  'Website Traffic',
  'App Install',
  'Conversion Optimizer',
  'Remarketing'
]

// Sample ad names
const adNames = [
  'Video Testimonial',
  'Product Showcase',
  'Limited Offer',
  'Customer Review',
  'How-To Guide',
  'Before and After',
  'Comparison Demo',
  'Feature Highlight',
  'FAQ Explainer',
  'User Generated'
]

// Sample ad headlines
const headlines = [
  'Transform Your Life Today',
  'Limited Time Offer - Act Now',
  'The Solution You\'ve Been Waiting For',
  'Join Thousands of Satisfied Customers',
  'Discover the Difference',
  'Why Settle for Less?',
  'Experience the Future Today',
  'Your Journey Starts Here',
  'The Ultimate Guide to Success',
  'New and Improved - See Results Fast'
]

// Sample campaign objectives
const objectives = [
  'AWARENESS',
  'CONSIDERATION',
  'CONVERSIONS',
  'LEAD_GENERATION',
  'APP_INSTALLS',
  'STORE_VISITS'
]

// Sample funnel stages
const funnelStages = [
  'TOFU', // Top of funnel
  'MOFU', // Middle of funnel
  'BOFU'  // Bottom of funnel
]

// Sample gender targeting
const genderTargeting = [
  'ALL',
  'MALE',
  'FEMALE'
]

// Sample age range targeting
const ageRangeTargeting = [
  '18-24',
  '25-34',
  '35-44',
  '45-54',
  '55-64',
  '65+'
]

// Function to generate random date within the last 60 days
function getRandomDate(daysBack = 60) {
  const today = new Date()
  const pastDate = new Date(today)
  pastDate.setDate(today.getDate() - Math.floor(Math.random() * daysBack))
  return pastDate.toISOString().split('T')[0] // YYYY-MM-DD format
}

// Function to generate random number between min and max
function getRandomNumber(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Function to generate random campaign start date (between 90 and 30 days ago)
function getRandomCampaignStartDate() {
  const today = new Date()
  const pastDate = new Date(today)
  pastDate.setDate(today.getDate() - getRandomNumber(30, 90))
  return pastDate.toISOString().split('T')[0] // YYYY-MM-DD format
}

// Function to generate random boolean with weighted probability
function getRandomBoolean(trueProb = 0.5) {
  return Math.random() < trueProb
}

// Function to get random item from array
function getRandomItem<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)]
}

// Function to generate metrics data
function generateMetricsData(count: number) {
  const metricsData = []

  for (let i = 0; i < count; i++) {
    const business_name = getRandomItem(businesses)
    const date = getRandomDate(60)
    
    // Generate reasonably related metrics
    const impressions = getRandomNumber(1000, 50000)
    const clicks = Math.floor(impressions * (getRandomNumber(1, 10) / 100)) // 1-10% CTR
    const spend = getRandomNumber(50, 5000)
    const conversions = Math.floor(clicks * (getRandomNumber(1, 30) / 100)) // 1-30% conversion rate
    const cpc = spend / clicks || 0
    const cpa = spend / conversions || 0
    
    metricsData.push({
      id: randomUUID(),
      business_name,
      date,
      impressions,
      clicks,
      ctr: clicks / impressions || 0,
      spend,
      cpc,
      conversions,
      cpa,
      leads: Math.floor(conversions * 0.7), // Assume ~70% of conversions are leads
      purchases: Math.floor(conversions * 0.3), // Assume ~30% of conversions are purchases
      account_id: `act_${getRandomNumber(100000, 999999)}`,
      campaign_id: `c_${getRandomNumber(100000, 999999)}`,
      campaign_name: getRandomItem(campaigns),
      ad_id: `a_${getRandomNumber(100000, 999999)}`,
      ad_name: getRandomItem(adNames),
      daily_budget: getRandomNumber(50, 500),
      cpm: (spend / impressions) * 1000 || 0,
      frequency: getRandomNumber(1, 5) + Math.random(),
      headline: getRandomItem(headlines),
      campaign_start_date: getRandomCampaignStartDate(),
      campaign_objective: getRandomItem(objectives),
      funnel_stage: getRandomItem(funnelStages),
      gender_targeting: getRandomItem(genderTargeting),
      age_range_targeting: getRandomItem(ageRangeTargeting)
    })
  }

  return metricsData
}

// Function to generate high CPA alert data
function generateHighCPAAlertData(count: number) {
  const alertData = []

  for (let i = 0; i < count; i++) {
    const business_name = getRandomItem(businesses)
    const date = getRandomDate(7) // Within last 7 days
    
    // Base metrics
    const impressions = getRandomNumber(1000, 50000)
    const clicks = Math.floor(impressions * (getRandomNumber(1, 10) / 100))
    const spend = getRandomNumber(500, 5000)
    
    // Generate high CPA scenario
    const conversions = getRandomNumber(1, 5) // Low conversions
    const cpa = spend / conversions // This will be high due to low conversions
    const thirty_day_avg_cpa = cpa / getRandomNumber(2, 4) // Make current CPA 2-4x higher than average
    
    alertData.push({
      id: randomUUID(),
      business_name,
      date,
      daily_cpa: cpa,
      thirty_day_avg_cpa,
      spend,
      conversions,
      account_id: `act_${getRandomNumber(100000, 999999)}`,
      campaign_id: `c_${getRandomNumber(100000, 999999)}`,
      campaign_name: getRandomItem(campaigns),
      ad_id: `a_${getRandomNumber(100000, 999999)}`,
      ad_name: getRandomItem(adNames),
      impressions,
      clicks,
      ctr: clicks / impressions || 0,
      daily_budget: getRandomNumber(50, 500),
      cpc: spend / clicks || 0,
      cpm: (spend / impressions) * 1000 || 0,
      frequency: getRandomNumber(1, 5) + Math.random(),
      created_at: new Date().toISOString(),
      flagged: getRandomBoolean(0.7), // 70% chance of being flagged
      flagged_reason: "CPA significantly above account average",
      leads: Math.floor(conversions * 0.7),
      purchases: Math.floor(conversions * 0.3),
      ai_summary: "This ad is showing a significantly higher cost per acquisition than the account average. Consider adjusting targeting or creative to improve performance.",
      preflagged: getRandomBoolean(0.3),
      campaign_start_date: getRandomCampaignStartDate(),
      campaign_objective: getRandomItem(objectives),
      funnel_stage: getRandomItem(funnelStages),
      gender_targeting: getRandomItem(genderTargeting),
      age_range_targeting: getRandomItem(ageRangeTargeting)
    })
  }

  return alertData
}

// Main function to populate database
async function populateDatabase() {
  try {
    console.log('Starting database population...')

    // Insert metrics data
    const metricsData = generateMetricsData(200)
    console.log(`Inserting ${metricsData.length} metrics records...`)
    
    const { error: metricsError } = await supabase
      .from('metrics')
      .upsert(metricsData)
    
    if (metricsError) {
      throw new Error(`Error inserting metrics data: ${metricsError.message}`)
    }
    
    console.log('✅ Metrics data inserted successfully')

    // The views (last_7_day_totals and alert_high_cpa) will be populated automatically
    // based on the metrics data we just inserted, as they are SQL views

    // However, we'll also insert some explicit high CPA alert data
    const highCPAData = generateHighCPAAlertData(50)
    console.log(`Inserting ${highCPAData.length} high CPA alert records...`)
    
    const { error: alertError } = await supabase
      .from('alert_high_cpa')
      .upsert(highCPAData)
    
    if (alertError) {
      // If this fails, it might be because alert_high_cpa is a view not a table
      console.log(`Note: Could not directly insert into alert_high_cpa. This is expected if it's a view: ${alertError.message}`)
    } else {
      console.log('✅ High CPA alert data inserted successfully')
    }

    // Generate and insert high spend alert data similar to high CPA
    // ...this would be similar to the high CPA data generation

    console.log('Database population completed successfully!')

  } catch (error) {
    console.error('Error populating database:', error)
    process.exit(1)
  }
}

// Run the population script
populateDatabase() 