-- Enable RLS
ALTER TABLE IF EXISTS meta_historical_data ENABLE ROW LEVEL SECURITY;

-- Create the meta_historical_data table if it doesn't exist
CREATE TABLE IF NOT EXISTS meta_historical_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_id TEXT NOT NULL,
    range_label TEXT NOT NULL,
    data JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Add a unique constraint on account_id and range_label
ALTER TABLE meta_historical_data
ADD CONSTRAINT meta_historical_data_account_range_unique UNIQUE (account_id, range_label);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_meta_historical_data_account_id ON meta_historical_data(account_id);
CREATE INDEX IF NOT EXISTS idx_meta_historical_data_range_label ON meta_historical_data(range_label);
CREATE INDEX IF NOT EXISTS idx_meta_historical_data_updated_at ON meta_historical_data(updated_at);

-- Grant permissions to the authenticated role
GRANT SELECT, INSERT, UPDATE, DELETE ON meta_historical_data TO authenticated;
GRANT USAGE ON SCHEMA public TO authenticated;

-- Grant permissions to access pg_tables (needed for the list-tables endpoint)
GRANT SELECT ON pg_tables TO authenticated;
GRANT SELECT ON pg_views TO authenticated;
GRANT SELECT ON information_schema.columns TO authenticated;
GRANT SELECT ON information_schema.key_column_usage TO authenticated;
GRANT SELECT ON information_schema.table_constraints TO authenticated;
GRANT SELECT ON information_schema.constraint_column_usage TO authenticated;

-- Create or replace RLS policies
CREATE POLICY "Enable read access for authenticated users"
    ON meta_historical_data FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Enable write access for authenticated users"
    ON meta_historical_data FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Enable update for authenticated users"
    ON meta_historical_data FOR UPDATE
    TO authenticated
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Enable delete for authenticated users"
    ON meta_historical_data FOR DELETE
    TO authenticated
    USING (true); 