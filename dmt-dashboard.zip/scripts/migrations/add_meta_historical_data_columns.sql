-- Add new columns to meta_historical_data table
ALTER TABLE meta_historical_data
ADD COLUMN IF NOT EXISTS range_label TEXT,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN IF NOT EXISTS data JSONB;

-- Add a unique constraint on account_id and range_label
ALTER TABLE meta_historical_data
ADD CONSTRAINT meta_historical_data_account_range_unique UNIQUE (account_id, range_label);

-- Add an index on range_label for faster lookups
CREATE INDEX IF NOT EXISTS idx_meta_historical_data_range_label ON meta_historical_data(range_label);

-- Add an index on updated_at for faster sorting
CREATE INDEX IF NOT EXISTS idx_meta_historical_data_updated_at ON meta_historical_data(updated_at); 