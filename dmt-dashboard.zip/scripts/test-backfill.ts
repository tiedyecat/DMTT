import { MetaDataBackfill } from '@/lib/MetaDataBackfill';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config({ path: '.env.local' });

const required = ['META_ACCESS_TOKEN', 'SUPABASE_URL', 'SUPABASE_KEY'];
for (const env of required) {
  if (!process.env[env]) {
    console.error(`Missing required environment variable: ${env}`);
    process.exit(1);
  }
}

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_KEY!
);

async function clearTestData(accountId: string) {
  console.log(`\nClearing test data for account ${accountId}...`);
  const { error } = await supabase
    .from('meta_historical_data')
    .delete()
    .eq('account_id', accountId);
  
  if (error) {
    console.error('Error clearing data:', error);
    return false;
  }
  return true;
}

async function verifyData(accountId: string) {
  console.log(`\nVerifying data for account ${accountId}...`);
  const { data, error } = await supabase
    .from('meta_historical_data')
    .select('*')
    .eq('account_id', accountId);

  if (error) {
    console.error('Error verifying data:', error);
    return false;
  }

  // Check data integrity
  const issues: string[] = [];
  for (const row of data) {
    if (!row.range_label) issues.push(`Missing range_label for row ${row.id}`);
    if (!row.updated_at) issues.push(`Missing updated_at for row ${row.id}`);
    if (!row.data) issues.push(`Missing data for row ${row.id}`);
    if (row.data?.data && !Array.isArray(row.data.data)) {
      issues.push(`Invalid data format for row ${row.id}`);
    }
  }

  // Print summary
  console.log('\nData Summary:');
  console.log('-------------');
  console.log(`Total ranges found: ${data.length}`);
  console.log('Ranges:', data.map(r => r.range_label).join(', '));
  console.log('\nData points per range:');
  data.forEach(row => {
    console.log(`${row.range_label}: ${row.data?.data?.length || 0} records`);
  });

  if (issues.length > 0) {
    console.log('\nIssues found:');
    issues.forEach(issue => console.log(`- ${issue}`));
    return false;
  }

  return true;
}

async function runBackfillTest(accountId: string) {
  console.log(`\nStarting backfill test for account ${accountId}...`);
  
  const backfiller = new MetaDataBackfill(
    process.env.META_ACCESS_TOKEN!,
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_KEY!
  );

  try {
    const result = await backfiller.backfillData(
      accountId,
      (range, data, error) => {
        if (error) {
          console.log(`❌ Range ${range.label}: Error - ${error}`);
        } else {
          console.log(`✓ Range ${range.label}: ${data?.data?.length || 0} records`);
        }
      }
    );

    console.log('\nBackfill Results:');
    console.log('----------------');
    console.log(`Success: ${result.success}`);
    console.log(`Errors: ${result.errors.length}`);
    if (result.errors.length > 0) {
      console.log('\nError Details:');
      result.errors.forEach(err => {
        console.log(`- Range ${err.range}: ${err.error}`);
      });
    }

    if (result.allTimeStats) {
      console.log('\nAll-Time Stats:');
      console.log('--------------');
      console.log(`First Data: ${result.allTimeStats.firstDataDate}`);
      console.log(`Last Data: ${result.allTimeStats.lastDataDate}`);
      console.log(`Total Spend: $${result.allTimeStats.totalSpend.toFixed(2)}`);
      console.log(`Total Impressions: ${result.allTimeStats.totalImpressions.toLocaleString()}`);
      console.log(`Total Clicks: ${result.allTimeStats.totalClicks.toLocaleString()}`);
      console.log(`Total Conversions: ${result.allTimeStats.totalConversions.toLocaleString()}`);
    }

    return result.success;
  } catch (error) {
    console.error('Test failed:', error);
    return false;
  }
}

async function main() {
  const testAccounts = [
    'act_797120043955249', // Physiq Fitness
    ...(process.env.TEST_ACCOUNT_ID ? [process.env.TEST_ACCOUNT_ID] : [])
  ];

  for (const accountId of testAccounts) {
    console.log(`\n=== Testing Account ${accountId} ===`);
    
    // Clear existing data
    await clearTestData(accountId);
    
    // Run backfill
    const success = await runBackfillTest(accountId);
    
    // Verify data
    const verified = await verifyData(accountId);
    
    console.log(`\nTest Results for ${accountId}:`);
    console.log(`Backfill Success: ${success ? '✓' : '❌'}`);
    console.log(`Data Verification: ${verified ? '✓' : '❌'}`);
  }
}

main().catch(console.error); 