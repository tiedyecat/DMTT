# DMT Dashboard Scripts

This directory contains utility scripts for the DMT Dashboard project.

## Database Population Script

The `populate-db.ts` script generates and inserts sample data into your Supabase database for testing and development purposes.

### Setup

1. Create a `.env` file in this directory based on the `env.example` template:
   ```
   cp env.example .env
   ```

2. Add your Supabase credentials to the `.env` file:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
   ```
   
   > ⚠️ Note: The service role key has admin privileges, so it should only be used for development purposes and never be exposed in client-side code.

3. Install dependencies:
   ```
   npm install
   ```

### Running the script

From the `scripts` directory, run:

```
npx ts-node populate-db.ts
```

This will:
1. Generate 200 random metrics records for various businesses
2. Attempt to insert data into the alert_high_cpa view (which may fail if it's a view, not a table)

### Generated data

The script populates:

- `metrics` table: Core performance metrics with random data across multiple businesses
- Views created in Supabase:
  - `last_7_day_totals`: Aggregated metrics for the last 7 days
  - `alert_high_cpa`: Entries where CPA is significantly higher than average

## Testing the Natural Language Query API

After populating the database, you can test the natural language query API endpoint at `/api/query`.

### Example queries:

- "Show me the last 7 days performance"
- "What were the high CPA alerts last week?"
- "Hey Fitness Fanatics, how was last week's performance?"
- "Hey Tech Innovators, show me high CPA alerts"

### API Response Format

The API returns responses in this format:

```json
{
  "type": "performance | alert | help",
  "data": [...],
  "message": "Human-readable description of the data"
}
```

### Request Format

Send a POST request to `/api/query` with:

```json
{
  "query": "Your natural language query here"
}
``` 