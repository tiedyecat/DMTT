-- Create a function to get all tables in the public schema
create or replace function get_tables()
returns table (
  table_name text,
  table_schema text
) language plpgsql security definer as $$
begin
  return query
  select 
    t.table_name::text,
    t.table_schema::text
  from information_schema.tables t
  where t.table_schema = 'public'
  and t.table_type = 'BASE TABLE'
  order by t.table_name;
end;
$$; 