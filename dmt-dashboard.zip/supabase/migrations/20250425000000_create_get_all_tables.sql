-- Create a function to get all tables and their details
CREATE OR REPLACE FUNCTION get_all_tables()
RETURNS TABLE (
    table_name text,
    table_type text,
    columns jsonb
) AS $$
BEGIN
    RETURN QUERY
    WITH table_columns AS (
        SELECT 
            c.table_name,
            jsonb_agg(
                jsonb_build_object(
                    'name', c.column_name,
                    'type', c.data_type,
                    'nullable', c.is_nullable = 'YES',
                    'default', c.column_default,
                    'is_primary_key', EXISTS (
                        SELECT 1 FROM information_schema.key_column_usage k
                        WHERE k.table_name = c.table_name 
                        AND k.column_name = c.column_name
                    )
                )
                ORDER BY c.ordinal_position
            ) as columns
        FROM information_schema.columns c
        WHERE c.table_schema = 'public'
        GROUP BY c.table_name
    )
    SELECT 
        t.table_name::text,
        CASE 
            WHEN t.table_type = 'BASE TABLE' THEN 'table'
            WHEN t.table_type = 'VIEW' THEN 'view'
            ELSE t.table_type::text
        END as table_type,
        COALESCE(tc.columns, '[]'::jsonb) as columns
    FROM information_schema.tables t
    LEFT JOIN table_columns tc ON t.table_name = tc.table_name
    WHERE t.table_schema = 'public'
    AND t.table_type IN ('BASE TABLE', 'VIEW')
    ORDER BY t.table_name;
END;
$$ LANGUAGE plpgsql; 