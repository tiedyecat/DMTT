-- Create view for last 7 days performance
create or replace view last_7_day_totals as
select 
    date,
    business_name,
    sum(spend) as total_spend,
    sum(clicks) as total_clicks,
    sum(conversions) as total_conversions,
    case 
        when sum(clicks) > 0 then sum(spend)::float / sum(clicks)
        else 0 
    end as cpc,
    case 
        when sum(conversions) > 0 then sum(spend)::float / sum(conversions)
        else 0 
    end as cpa
from metrics
where date >= current_date - interval '7 days'
group by date, business_name
order by date desc, business_name;

-- Create view for high CPA alerts
create or replace view alert_high_cpa as
with business_avg_cpa as (
    select 
        business_name,
        avg(case when conversions > 0 then spend::float / conversions else 0 end) as avg_cpa
    from metrics
    where date >= current_date - interval '30 days'
    group by business_name
)
select 
    m.date,
    m.business_name,
    m.spend,
    m.conversions,
    case 
        when m.conversions > 0 then m.spend::float / m.conversions
        else 0 
    end as daily_cpa,
    b.avg_cpa as thirty_day_avg_cpa
from metrics m
join business_avg_cpa b on m.business_name = b.business_name
where 
    m.date >= current_date - interval '7 days'
    and m.conversions > 0
    and (m.spend::float / m.conversions) > (b.avg_cpa * 1.5)
order by m.date desc, m.business_name; 